(function(){
  Object.assign(T.es, {
    remove: 'Borrar',
    restore: 'Restaurar',
    refreshList: 'Actualizar lista',
    performanceMonitor: 'Monitor de rendimiento',
    startWithWindowsManager: 'Arrancar manager con Windows',
    startServerWithManager: 'Iniciar servidor al abrir el manager',
    saveStartupOptions: 'Guardar arranque',
    startupOptions: 'Inicio automático',
    startupOptionsHint: 'Puedes hacer que el manager arranque con Windows y, si quieres, que al abrirse arranque también el servidor.',
    inventoryPlayersWithSnapshots: 'Jugadores con snapshots guardados',
    inventorySelectHint: 'Pulsa un jugador del historial para ver directamente su último inventario guardado, aunque esté offline.',
    inventoryLatestSnapshot: 'Último snapshot guardado',
    inventoryLiveRead: 'Inventario en vivo',
    inventorySnapshotView: 'Último snapshot',
    inventoryNoSnapshot: 'Ese jugador todavía no tiene snapshots guardados.',
    inventoryClickPlayer: 'Selecciona un jugador de la lista para ver su inventario.',
    moderationPlayerPicker: 'Jugador para moderación',
    moderationPlayerPickerHint: 'Aquí tienes toda la lista de jugadores online e históricos para elegir rápido.',
    moderationChoosePlayer: 'Elegir jugador',
    botsTopChooserTitle: 'Elige qué bot quieres controlar',
    botsTopStartAll: 'Iniciar todos',
    botsTopStopAll: 'Parar todos',
    botsTopPrimary: 'Bot principal',
    botsTopNoBots: 'No hay bots configurados.',
    chooseBotToStart: 'Elige qué bot quieres iniciar',
    chooseBotToStop: 'Elige qué bot quieres parar',
    chooseBotToRestart: 'Elige qué bot quieres reiniciar',
    close: 'Cerrar',
    startTopChooser: 'Iniciar bot',
    stopTopChooser: 'Parar bot',
    primaryTopAutostart: 'Iniciar con botón superior',
    primaryAutoStartWithServer: 'Iniciar con el servidor',
    botWindowsStart: 'Arrancar con Windows',
    managerWindowsStart: 'Arrancar manager con Windows',
    botsPanelTitle: 'Bots externos múltiples',
    botsPanelHint: 'Aquí configuras el bot principal y los bots adicionales. Desde los botones superiores eliges cuál arrancar o parar.',
    primaryBotTitle: 'Bot principal',
    extraBotsTitle: 'Bots adicionales',
    addBot: 'Añadir bot',
    saveBots: 'Guardar bots',
    botName: 'Nombre',
    botEntry: 'Archivo de arranque',
    botEnabled: 'Activo',
    botAutoStart: 'Iniciar con botón superior',
    botWithServer: 'Iniciar con el servidor',
    noExtraBots: 'No hay bots adicionales todavía.',
    selectPlayerFromList: 'Seleccionar jugador',
    recentSnapshot: 'Últimos snapshots',
    moderationTitleShort: 'Moderación',
    performanceHostCpu: 'CPU host',
    performanceHostRam: 'RAM host',
    performanceDisk: 'Disco servidor',
    performanceManagerUptime: 'Uptime manager',
    performanceServerUptime: 'Uptime servidor',
    performanceManagerRam: 'RAM manager',
    performanceServerRam: 'RAM servidor',
    inventoryOnlineOfflineTitle: 'Inventario online / offline',
    inventoryPanelTitle: 'Inventario',
    inventoryPanelText: 'Aquí puedes ver el inventario en vivo o la última captura guardada del jugador seleccionado.',
    statusOnline: 'Online'
  });
  Object.assign(T.en, {
    remove: 'Delete',
    restore: 'Restore',
    refreshList: 'Refresh list',
    performanceMonitor: 'Performance',
    startWithWindowsManager: 'Start manager with Windows',
    startServerWithManager: 'Start server when manager opens',
    saveStartupOptions: 'Save startup',
    startupOptions: 'Automatic startup',
    startupOptionsHint: 'Make the manager start with Windows and optionally start the server when the manager opens.',
    inventoryPlayersWithSnapshots: 'Players with saved snapshots',
    inventorySelectHint: 'Click a history player to view the latest saved inventory even while offline.',
    inventoryLatestSnapshot: 'Latest saved snapshot',
    inventoryLiveRead: 'Live inventory',
    inventorySnapshotView: 'Latest snapshot',
    inventoryNoSnapshot: 'This player has no saved snapshots yet.',
    inventoryClickPlayer: 'Select a player to view inventory.',
    moderationPlayerPicker: 'Moderation player',
    moderationPlayerPickerHint: 'Choose any online or history player from one dark dropdown.',
    moderationChoosePlayer: 'Choose player',
    botsTopChooserTitle: 'Choose which bot to control',
    botsTopStartAll: 'Start all',
    botsTopStopAll: 'Stop all',
    botsTopPrimary: 'Primary bot',
    botsTopNoBots: 'No bots configured.',
    chooseBotToStart: 'Choose which bot to start',
    chooseBotToStop: 'Choose which bot to stop',
    chooseBotToRestart: 'Choose which bot to restart',
    startTopChooser: 'Start bot',
    stopTopChooser: 'Stop bot',
    primaryTopAutostart: 'Start with top button',
    primaryAutoStartWithServer: 'Start with server',
    botWindowsStart: 'Start with Windows',
    managerWindowsStart: 'Start manager with Windows',
    botsPanelTitle: 'Multiple external bots',
    botsPanelHint: 'Configure the primary bot and extra bots here. The top buttons let you choose which bot to start or stop.',
    primaryBotTitle: 'Primary bot',
    extraBotsTitle: 'Additional bots',
    addBot: 'Add bot',
    saveBots: 'Save bots',
    botName: 'Name',
    botEntry: 'Startup file',
    botEnabled: 'Enabled',
    botAutoStart: 'Start with top button',
    botWithServer: 'Start with server',
    noExtraBots: 'No additional bots yet.',
    selectPlayerFromList: 'Select player',
    recentSnapshot: 'Recent snapshots',
    moderationTitleShort: 'Moderation',
    performanceHostCpu: 'Host CPU',
    performanceHostRam: 'Host RAM',
    performanceDisk: 'Server disk',
    performanceManagerUptime: 'Manager uptime',
    performanceServerUptime: 'Server uptime',
    performanceManagerRam: 'Manager RAM',
    performanceServerRam: 'Server RAM',
    inventoryOnlineOfflineTitle: 'Online / offline inventory',
    inventoryPanelTitle: 'Inventory',
    inventoryPanelText: 'Here you can view the live inventory or the latest saved snapshot of the selected player.',
    statusOnline: 'Online'
  });

  const esc = v => (typeof escapeHtml === 'function' ? escapeHtml(v ?? '') : String(v ?? ''));
  const fmtNum = n => Number.isFinite(Number(n)) ? Number(n) : null;
  const fmtPct = v => (Number.isFinite(Number(v)) ? `${Number(v).toFixed(1)}%` : '-');
  const fmtGb = v => (Number.isFinite(Number(v)) ? `${Number(v).toFixed(2)} GB` : '-');
  const fmtMem = m => m ? `${fmtGb(m.used_gb)} / ${fmtGb(m.total_gb)} · ${fmtPct(m.percent)}` : '-';
  const fmtDisk = d => d ? `${fmtGb(d.used_gb)} / ${fmtGb(d.total_gb)} · ${fmtPct(d.percent)}` : '-';
  const fmtProc = m => m ? fmtGb(m.rss_gb) : '-';
  function fmtUp(seconds){ const n = Number(seconds); if(!Number.isFinite(n) || n < 0) return '-'; const d=Math.floor(n/86400), h=Math.floor((n%86400)/3600), m=Math.floor((n%3600)/60); if(d>0) return `${d}d ${h}h ${m}m`; if(h>0) return `${h}h ${m}m`; return `${m}m`; }

  function injectStyles(){
    if(document.getElementById('kw-v38-styles')) return;
    const css = `
      .kw-dark-select, .kw-dark-select option{background:#08101b;color:#eef5ff;border:1px solid rgba(120,150,190,.22)}
      .kw-player-pick-grid{display:grid;grid-template-columns:minmax(260px,340px) 1fr;gap:18px}
      .kw-player-list{max-height:520px;overflow:auto;display:flex;flex-direction:column;gap:8px;padding-right:4px}
      .kw-player-row{display:flex;justify-content:space-between;gap:10px;align-items:center;background:rgba(5,12,24,.55);border:1px solid rgba(113,151,196,.14);padding:10px 12px;border-radius:14px;color:#eef5ff;cursor:pointer}
      .kw-player-row.active{border-color:rgba(96,163,255,.55);box-shadow:0 0 0 1px rgba(96,163,255,.25) inset}
      .kw-player-row small{display:block;color:#a8b9cf;line-height:1.35}
      .kw-player-row .badge{white-space:nowrap}
      .kw-startup-card .inline-actions{margin-top:14px;align-items:center;flex-wrap:wrap}
      .kw-check-chip{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:14px;background:rgba(5,12,24,.45);border:1px solid rgba(113,151,196,.14)}
      .kw-check-chip input{width:18px;height:18px}
      .kw-bot-modal-backdrop{position:fixed;inset:0;background:rgba(2,6,12,.68);display:flex;align-items:center;justify-content:center;z-index:9999;padding:20px}
      .kw-bot-modal{max-width:760px;width:100%;background:linear-gradient(180deg,#071221,#08172a);border:1px solid rgba(113,151,196,.18);border-radius:22px;padding:18px;box-shadow:0 18px 70px rgba(0,0,0,.45)}
      .kw-bot-modal .list{display:flex;flex-direction:column;gap:10px;margin-top:14px}
      .kw-bot-modal .row{display:flex;justify-content:space-between;gap:12px;align-items:center;padding:12px 14px;border-radius:16px;background:rgba(255,255,255,.03);border:1px solid rgba(113,151,196,.12)}
      .kw-bot-modal .row .meta{display:flex;flex-direction:column;gap:4px}
      .kw-mini-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px}
      .kw-mini-stat{padding:18px 18px 16px}
      .kw-mini-stat small{display:block;color:#b6c4d9;text-transform:uppercase;letter-spacing:.04em;margin-bottom:8px}
      .kw-mini-stat strong{font-size:18px;line-height:1.2;display:block}
      .kw-inventory-snapshots-list{display:flex;flex-direction:column;gap:8px;margin-top:12px}
      .kw-inventory-snapshots-list button{width:100%;text-align:left}
      @media (max-width: 1100px){ .kw-player-pick-grid{grid-template-columns:1fr} }
    `;
    const style=document.createElement('style'); style.id='kw-v38-styles'; style.textContent=css; document.head.appendChild(style);
  }

  function clearVersionMarkers(){
    const eye=document.getElementById('eyebrow'); if(eye) eye.textContent=t('eyebrow');
    const sub=document.getElementById('heroSubtitle'); if(sub){ sub.textContent=t('heroSubtitle'); }
    const backupBtn=document.getElementById('btnBackupTop'); if(backupBtn) backupBtn.style.display='none';
    const startBotBtn=document.getElementById('btnStartBotTop'); if(startBotBtn) startBotBtn.textContent=t('startTopChooser');
    const stopBotBtn=document.getElementById('btnStopBotTop'); if(stopBotBtn) stopBotBtn.textContent=t('stopTopChooser');
  }

  const _renderStaticTexts = renderStaticTexts;
  renderStaticTexts = function(){
    const out = _renderStaticTexts.apply(this, arguments);
    injectStyles();
    clearVersionMarkers();
    return out;
  };
  const _render = render;
  render = function(preserve){ const out = _render(preserve); setTimeout(()=>{injectStyles(); clearVersionMarkers();},0); return out; };

  function ensurePlayersHistoryFresh(){
    if (typeof loadPlayersHistoryList === 'function') loadPlayersHistoryList(true).catch(()=>{});
    if (typeof loadPlayerProfile === 'function') loadPlayerProfile(true).catch(()=>{});
  }
  const _refreshState = refreshState;
  refreshState = async function(silent){ const out = await _refreshState(silent); if(state.section==='inventory' || state.section==='moderation') ensurePlayersHistoryFresh(); setTimeout(clearVersionMarkers,0); return out; };
  const _go = go;
  go = function(section){ const out = _go(section); if(section==='inventory' || section==='moderation'){ setTimeout(ensurePlayersHistoryFresh,80); } return out; };

  function performanceCardsHtml(){
    const p = (state.state && state.state.performance) || {};
    const cards = [
      [t('performanceHostCpu'), fmtPct(p.host_cpu_percent)],
      [t('performanceHostRam'), fmtMem(p.host_memory)],
      [t('performanceDisk'), fmtDisk(p.disk)],
      [t('performanceManagerUptime'), fmtUp(p.manager_uptime_seconds)],
      [t('performanceServerUptime'), fmtUp(p.server_uptime_seconds)],
      [t('performanceManagerRam'), fmtProc(p.manager_memory)],
      [t('performanceServerRam'), fmtProc(p.server_memory)],
    ];
    return `<div class="kw-mini-stats">${cards.map(([label,val])=>`<div class="stat card kw-mini-stat"><small>${label}</small><strong>${esc(val)}</strong></div>`).join('')}</div>`;
  }

  async function saveStartupFlags(){
    try {
      const payload = {
        start_with_windows_manager: !!document.getElementById('startupManagerWindows')?.checked,
        start_server_with_manager: !!document.getElementById('startupServerWithManager')?.checked
      };
      const res = await api('/api/config/save', 'POST', payload);
      toast(res.message || t('settingsSaved'));
      await refreshState(true);
      go('dashboard');
    } catch(err){ toast(err.message, true); }
  }
  window.saveStartupFlags = saveStartupFlags;

  function startupOptionsHtml(){
    const cfg = (state.state && state.state.config) || {};
    return `<div class="card panel kw-startup-card"><h2>${t('startupOptions')}</h2><div class="help-text" style="margin-top:6px">${t('startupOptionsHint')}</div><div class="inline-actions"><label class="kw-check-chip"><input id="startupManagerWindows" type="checkbox" ${cfg.start_with_windows_manager ? 'checked' : ''}><span>${t('startWithWindowsManager')}</span></label><label class="kw-check-chip"><input id="startupServerWithManager" type="checkbox" ${cfg.start_server_with_manager ? 'checked' : ''}><span>${t('startServerWithManager')}</span></label><button class="btn btn-primary" onclick="saveStartupFlags()">${t('saveStartupOptions')}</button></div></div>`;
  }

  views.dashboard = function(){
    const s = state.state || {};
    const config = s.config || {};
    const autoRestartLabel = config.auto_restart_enabled ? `${t('enabled')} · ${config.auto_restart_delay_seconds || 15}s` : t('disabled');
    const startedAt = s.started_at ? formatDateTime(s.started_at) : '-';
    const recentLines = (s.console_lines || []).slice(-12);
    return `
      <div class="grid">
        <div class="stats stats-6">
          <div class="stat card"><small>${t('status')}</small><strong>${s.running ? t('on') : t('off')}</strong></div>
          <div class="stat card"><small>${t('playersOnline')}</small><strong>${(s.players_cache || []).length}</strong></div>
          <div class="stat card"><small>${t('pid')}</small><strong>${s.pid || '-'}</strong></div>
          <div class="stat card"><small>${t('startedAt')}</small><strong>${startedAt}</strong></div>
          <div class="stat card"><small>${t('autoRestart')}</small><strong>${autoRestartLabel}</strong></div>
        </div>
        ${performanceCardsHtml()}
        <div class="grid grid-2">
          <div class="card panel">
            <div class="panel-head-inline"><h2>${t('generalStatus')}</h2><span class="badge ${s.running ? 'ok' : 'off'}">${s.running ? t('serverOn') : t('serverOff')}</span></div>
            <div class="label-grid">
              <div>${t('serverFolder')}</div><div>${esc(config.server_folder || '-')}</div>
              <div>${t('executable')}</div><div>${esc(config.executable_path || '-')}</div>
              <div>${t('workingFolder')}</div><div>${esc(config.working_directory || '-')}</div>
              <div>${t('realXml')}</div><div>${esc(config.xml_path || '-')}</div>
              <div>${t('backupFolder')}</div><div>${esc(config.backup_folder || '-')}</div>
              <div>${t('inventoryIconsStatus')}</div><div>${esc(config.item_icons_folder || t('noIconsFolder'))}</div>
              <div>${t('telnet')}</div><div>${esc(config.telnet_host || '-')} : ${esc(config.telnet_port || '-')}</div>
              <div>${t('panelAddress')}</div><div>${esc(config.panel_host || '-')} : ${esc(config.panel_port || '-')}</div>
            </div>
            <div class="inline-actions" style="margin-top:14px"><button class="btn" onclick="go('backups')">${t('backups')}</button><button class="btn" onclick="go('tasks')">${t('scheduledTasks')}</button><button class="btn" onclick="go('inventory')">${t('inventory')}</button></div>
          </div>
          <div class="card panel">
            <h2>${t('recentActivity')}</h2>
            <div class="console-box compact-box"><div class="console-output">${recentLines.length ? esc(recentLines.join('\n')) : `<span class="empty-note">${t('noRecentEvents')}</span>`}</div></div>
          </div>
        </div>
        ${startupOptionsHtml()}
      </div>`;
  };

  function currentProfileRecord(){ return state.playerProfile && state.playerProfile.record ? state.playerProfile.record : null; }
  function currentLatestSnapshot(){
    const rec = currentProfileRecord();
    const snaps = (rec && rec.inventory_snapshots) ? rec.inventory_snapshots : [];
    if (!snaps || !snaps.length) return null;
    const reversed = snaps.slice().reverse();
    const idx = Math.max(0, Math.min(Number(state.v38SnapshotIndex || 0), reversed.length - 1));
    return reversed[idx] || reversed[0];
  }
  function inventoryTargetPlayer(){
    if (state.historySelectedKey && currentProfileRecord()) return historyPlayerFromRecord(currentProfileRecord());
    return selectedPlayer();
  }
  function inventoryDetailHtml(){
    const player = inventoryTargetPlayer();
    const rec = currentProfileRecord();
    const liveData = player && !state.historySelectedKey ? currentInventoryData() : null;
    const latest = currentLatestSnapshot();
    const showData = liveData && !liveData.error ? liveData : latest;
    const sourceTitle = liveData && !liveData.error ? t('inventoryLiveRead') : t('inventorySnapshotView');
    if (!player && !rec) return `<div class="card panel"><div class="empty-note">${t('inventoryClickPlayer')}</div></div>`;
    if (!showData) return `<div class="card panel"><div class="panel-head-inline"><div><h2>${t('inventoryLatestSnapshot')}</h2></div><span class="badge default">${esc(rec?.primary_name || player?.name || '-')}</span></div><div class="empty-note" style="margin-top:14px">${t('inventoryNoSnapshot')}</div></div>`;
    const hasData = ((showData.belt && showData.belt.length) || (showData.bag && showData.bag.length) || (showData.equipment && Object.keys(showData.equipment).length));
    const snapshots = ((rec && rec.inventory_snapshots) || []).slice().reverse();
    return `<div class="card panel">
      <div class="panel-head-inline"><div><h2>${esc(rec?.primary_name || player?.name || '-')}</h2><div class="help-text" style="margin-top:6px">${sourceTitle}${showData.updated_at || showData.at ? ' · ' + esc(formatDateTime(showData.updated_at || showData.at)) : ''}</div></div><span class="badge ${state.historySelectedKey ? 'default':'ok'}">${state.historySelectedKey ? t('historyStatusOffline') : t('historyStatusOnline')}</span></div>
      ${hasData ? `<div class="kw-inv-panels" style="margin-top:12px"><div class="card panel inventory-panel compact-inv-panel"><h3>${t('belt')}</h3>${inventoryItemsHtml(showData.belt || [], t('inventoryEmptySection'))}</div><div class="card panel inventory-panel compact-inv-panel"><h3>${t('bag')}</h3>${inventoryItemsHtml(showData.bag || [], t('inventoryEmptySection'))}</div><div class="card panel inventory-panel compact-inv-panel"><h3>${t('equipment')}</h3>${inventoryEquipmentHtml(showData.equipment || {})}</div></div>` : `<div class="empty-note" style="margin-top:12px">${t('inventoryNoData')}</div>`}
      <div class="inline-actions wrap-actions" style="margin-top:14px">${!state.historySelectedKey ? `<button class="btn btn-primary" onclick="loadPlayerInventory()">${t('inventoryLoad')}</button>` : ''}<button class="btn" onclick="go('moderation')">${t('moderation')}</button></div>
      ${snapshots.length > 1 ? `<div class="kw-inventory-snapshots-list">${snapshots.slice(0,8).map((row, idx)=>`<button class="btn ${idx===0 ? 'btn-primary':''}" onclick="showSnapshotIndex(${idx})">${esc(formatDateTime(row.at || row.updated_at || '-'))} · ${esc(snapshotSummaryText(row))}</button>`).join('')}</div>` : ''}
    </div>`;
  }
  window.showSnapshotIndex = function(idx){
    state.v38SnapshotIndex = Number(idx) || 0;
    render(true);
  };

  function historySnapshotRows(){ return (state.playerHistoryList || []).filter(r => Number(r.snapshot_count || 0) > 0); }
  function inventorySidebarHtml(){
    const online = state.state?.players_cache || [];
    const historyRows = historySnapshotRows();
    return `<div class="card panel"><div class="panel-head-inline"><div><h2>${t('inventory')}</h2><div class="help-text" style="margin-top:6px">${t('inventorySelectHint')}</div></div><div class="inline-actions"><button class="btn" onclick="refreshPlayers()">${t('refreshPlayers')}</button></div></div><div class="kw-player-pick-grid"><div><h3>${t('playersOnline')}</h3><div class="kw-player-list">${online.length ? online.map((p, idx)=>`<button class="kw-player-row ${!state.historySelectedKey && state.selectedPlayerIndex===idx ? 'active':''}" onclick="v38PickOnline(${idx})"><span><strong>${esc(playerDisplayName(p))}</strong><small>${esc(playerSteamText(p))}</small></span><span class="badge ok">${t('historyStatusOnline')}</span></button>`).join('') : `<div class="empty-note">${t('inventoryNoOnlinePlayers')}</div>`}</div><h3 style="margin-top:18px">${t('inventoryPlayersWithSnapshots')}</h3><div class="kw-player-list">${historyRows.length ? historyRows.map(row=>`<button class="kw-player-row ${state.historySelectedKey===row.key ? 'active':''}" onclick="v38PickHistory('${String(row.key||'').replace(/'/g,"\\'")}')"><span><strong>${esc(row.primary_name || '-')}</strong><small>${esc(historyIdText(row))}</small></span><span class="badge default">${esc(String(row.snapshot_count || 0))}</span></button>`).join('') : `<div class="empty-note">${t('inventoryNoHistoryCandidates')}</div>`}</div></div><div>${inventoryDetailHtml()}</div></div></div>`;
  }
  window.v38PickOnline = function(idx){ state.v38SnapshotIndex = 0; state.historySelectedKey=''; selectPlayer(idx); setTimeout(()=>{ loadPlayerProfile(true); render(true); }, 40); };
  window.v38PickHistory = function(key){ state.v38SnapshotIndex = 0; state.historySelectedKey=key||''; state.selectedPlayerIndex=null; loadPlayerProfile(true).then(()=>render(true)); };

  // override inventory view fully using active profile / latest snapshot
  views.inventory = function(){ return `<div class="grid">${inventorySidebarHtml()}</div>`; };

  const _loadPlayerInventory = loadPlayerInventory;
  loadPlayerInventory = async function(silent=false){
    const target = inventoryTargetPlayer();
    if(!target){ if(!silent) toast(t('noPlayerSelected'), true); return; }
    try {
      const res = await api('/api/player/inventory', 'POST', { player: target });
      state.playerInventories[inventoryPlayerKey(target) || '__history_preview__'] = res.data || null;
      toast(res.message || t('inventoryReload'));
      await loadPlayerProfile(true);
      render(true);
    } catch(err){ toast(err.message, true); }
  };

  // moderation dropdown + cleaner layout
  function moderationPickerHtml(){
    const online = (state.state?.players_cache || []).map((p, idx)=>({value:`live:${idx}`, label:`${playerDisplayName(p)} · ${playerSteamText(p)}`}));
    const history = (state.playerHistoryList || []).map(r=>({value:`hist:${r.key}`, label:`${r.primary_name || '-'} · ${historyIdText(r)}`}));
    const currentValue = state.historySelectedKey ? `hist:${state.historySelectedKey}` : (Number.isInteger(state.selectedPlayerIndex) ? `live:${state.selectedPlayerIndex}` : '');
    return `<div class="card panel"><div class="panel-head-inline"><div><h2>${t('moderationTitle')}</h2><div class="help-text" style="margin-top:6px">${t('moderationPlayerPickerHint')}</div></div><div class="inline-actions"><button class="btn" onclick="refreshPlayers()">${t('refreshPlayers')}</button></div></div><div class="field"><label>${t('moderationPlayerPicker')}</label><select id="moderationPlayerPicker" class="kw-dark-select" onchange="v38ModerationSelect(this.value)"><option value="">${t('moderationChoosePlayer')}</option>${online.length ? `<optgroup label="${t('playersOnline')}">${online.map(row=>`<option value="${esc(row.value)}" ${currentValue===row.value ? 'selected':''}>${esc(row.label)}</option>`).join('')}</optgroup>`:''}${history.length ? `<optgroup label="${t('historyTitle')}">${history.map(row=>`<option value="${esc(row.value)}" ${currentValue===row.value ? 'selected':''}>${esc(row.label)}</option>`).join('')}</optgroup>`:''}</select></div></div>`;
  }
  window.v38ModerationSelect = function(value){
    const raw = String(value || '');
    if(!raw) return;
    if(raw.startsWith('live:')){ state.historySelectedKey=''; selectPlayer(Number(raw.split(':')[1]||0)); loadPlayerProfile(true).then(()=>render(true)); return; }
    if(raw.startsWith('hist:')){ state.historySelectedKey=raw.slice(5); state.selectedPlayerIndex=null; loadPlayerProfile(true).then(()=>render(true)); return; }
  };

  const _moderationViewBase = views.moderation;
  views.moderation = function(){
    const body = _moderationViewBase ? _moderationViewBase() : '';
    return `<div class="grid">${moderationPickerHtml()}${body}</div>`;
  };

  // bots page clean layout
  function ensureBotDraft(){
    const cfg = (state.state && state.state.bot_config) || {};
    const sig = JSON.stringify({list: cfg.external_bots || [], primary: cfg.external_bot_entry || '', msw: !!cfg.manager_start_with_windows, psw: !!cfg.primary_start_with_windows, pas: !!cfg.primary_auto_start_with_server});
    if(state._botDraftSig !== sig){ state._botDraftSig = sig; state._extraBotsDraft = JSON.parse(JSON.stringify(cfg.external_bots || [])); }
    return cfg;
  }
  window.v38AddBotRow = function(){ ensureBotDraft(); state._extraBotsDraft.push({name:'Bot', entry:'', enabled:true, auto_start_with_server:true, start_with_windows:false}); render(true); };
  window.v38RemoveBotRow = function(idx){ ensureBotDraft(); state._extraBotsDraft.splice(idx,1); render(true); };
  window.v38BrowseBotRow = function(idx){ browseField(`v38_bot_entry_${idx}`, 'bot_entry', t('selectBotFolder')); };
  window.v38BotActionOne = async function(botId, action){
    try{ const res = await api(`/api/bots/${action}`, 'POST', {id: botId}); toast(res.message || 'OK'); await refreshState(true); go('discordbot'); }catch(err){ toast(err.message, true); }
  };
  window.v38SaveBotsConfig = async function(){
    try{
      const cfg = ensureBotDraft();
      const payload = {
        external_bot_entry: document.getElementById('bot_external_bot_entry')?.value || '',
        primary_start_with_windows: !!document.getElementById('v38_primary_start_with_windows')?.checked,
        primary_auto_start_with_server: !!document.getElementById('v38_primary_auto_start_server')?.checked,
        external_bots: (state._extraBotsDraft || []).map((row, idx)=>({
          id: row.id || '',
          name: document.getElementById(`v38_bot_name_${idx}`)?.value || row.name || `Bot ${idx+1}`,
          entry: document.getElementById(`v38_bot_entry_${idx}`)?.value || '',
          enabled: !!document.getElementById(`v38_bot_enabled_${idx}`)?.checked,
          auto_start_with_server: !!document.getElementById(`v38_bot_auto_${idx}`)?.checked,
          start_with_windows: !!document.getElementById(`v38_bot_windows_${idx}`)?.checked,
        }))
      };
      const res = await api('/api/bot/config/save', 'POST', payload);
      toast(res.message || t('saved'));
      state._botDraftSig='';
      await refreshState(true);
      go('discordbot');
    } catch(err){ toast(err.message, true); }
  };

  views.discordbot = function(){
    const cfg = ensureBotDraft();
    const extras = state._extraBotsDraft || [];
    const statuses = (state.state && state.state.external_bots_status) || [];
    const statusMap = Object.fromEntries(statuses.map(x => [String(x.id||''), x]));
    return `<div class="grid">
      <div class="card panel"><div class="panel-head-inline"><div><h2>${t('botsPanelTitle')}</h2><div class="help-text" style="margin-top:6px">${t('botsPanelHint')}</div></div><div class="inline-actions"><button class="btn" onclick="v38AddBotRow()">${t('addBot')}</button><button class="btn btn-primary" onclick="v38SaveBotsConfig()">${t('saveBots')}</button></div></div></div>
      <div class="grid grid-2">
        <div class="card panel"><h2>${t('primaryBotTitle')}</h2><div class="input-grid">${fieldBrowse('bot_external_bot_entry', t('botEntry'), cfg.external_bot_entry || '', 'bot_entry', t('selectBotFolder'))}<div class="field"><label>${t('status')}</label><input value="${esc(state.state?.bot_running ? t('on') : (cfg.external_bot_entry ? t('off') : '-'))}" disabled></div></div><div class="inline-actions wrap-actions" style="margin-top:14px"><label class="kw-check-chip"><input id="v38_primary_start_with_windows" type="checkbox" ${cfg.primary_start_with_windows ? 'checked' : ''}><span>${t('botWindowsStart')}</span></label><label class="kw-check-chip"><input id="v38_primary_auto_start_server" type="checkbox" ${cfg.primary_auto_start_with_server !== false ? 'checked' : ''}><span>${t('primaryAutoStartWithServer')}</span></label><button class="btn btn-primary" onclick="v38BotActionOne('primary','start')">${t('start')}</button><button class="btn" onclick="v38BotActionOne('primary','restart')">${t('restart')}</button><button class="btn btn-danger" onclick="v38BotActionOne('primary','stop')">${t('stop')}</button></div></div>
        <div class="card panel"><h2>${t('extraBotsTitle')}</h2>${extras.length ? extras.map((row, idx)=>{ const st = statusMap[String(row.id||'')] || {}; return `<div class="card" style="padding:12px;margin-bottom:12px"><div class="grid grid-2"><div class="field"><label>${t('botName')}</label><input id="v38_bot_name_${idx}" value="${esc(row.name || '')}"></div><div class="field"><label>${t('status')}</label><input value="${esc(st.running ? t('on') : t('off'))}" disabled></div></div><div class="field" style="margin-top:10px"><label>${t('botEntry')}</label><div class="inline-actions"><input id="v38_bot_entry_${idx}" value="${esc(row.entry || '')}" style="flex:1"><button class="btn" type="button" onclick="v38BrowseBotRow(${idx})">...</button></div></div><div class="inline-actions wrap-actions" style="margin-top:10px"><label class="kw-check-chip"><input id="v38_bot_enabled_${idx}" type="checkbox" ${row.enabled !== false ? 'checked' : ''}><span>${t('botEnabled')}</span></label><label class="kw-check-chip"><input id="v38_bot_auto_${idx}" type="checkbox" ${row.auto_start_with_server !== false ? 'checked' : ''}><span>${t('botWithServer')}</span></label><label class="kw-check-chip"><input id="v38_bot_windows_${idx}" type="checkbox" ${row.start_with_windows ? 'checked' : ''}><span>${t('botWindowsStart')}</span></label></div><div class="inline-actions wrap-actions" style="margin-top:10px"><button class="btn btn-primary" type="button" onclick="v38BotActionOne('${esc(row.id || '')}','start')">${t('start')}</button><button class="btn" type="button" onclick="v38BotActionOne('${esc(row.id || '')}','restart')">${t('restart')}</button><button class="btn btn-danger" type="button" onclick="v38BotActionOne('${esc(row.id || '')}','stop')">${t('stop')}</button><button class="btn btn-danger" type="button" onclick="v38RemoveBotRow(${idx})">${t('remove')}</button></div></div>`; }).join('') : `<div class="empty-note">${t('noExtraBots')}</div>`}</div>
      </div>
    </div>`;
  };

  function botsCatalog(){
    const cfg = (state.state && state.state.bot_config) || {};
    const extras = (state.state && state.state.external_bots_status) || [];
    const rows = [];
    if(String(cfg.external_bot_entry || '').trim()) rows.push({id:'primary', name:t('botsTopPrimary'), subtitle:cfg.external_bot_entry || '', running: !!state.state?.bot_running});
    extras.forEach(row=>{ if(row && row.id) rows.push({id:String(row.id), name: row.name || row.id, subtitle: row.entry || '', running: !!row.running}); });
    return rows;
  }
  window.closeBotChooser = function(){ const el=document.getElementById('kwBotChooser'); if(el) el.remove(); };
  window.v38BotChooserAction = async function(id, action){
    try {
      let res;
      if(id === '__all__'){
        const map = {start:'/api/bot/start', stop:'/api/bot/stop', restart:'/api/bot/restart'};
        res = await api(map[action], 'POST', {});
      } else {
        res = await api(`/api/bots/${action}`, 'POST', {id});
      }
      toast(res.message || 'OK');
      closeBotChooser();
      await refreshState(true);
    } catch(err){ toast(err.message, true); }
  };
  function openBotChooser(action){
    closeBotChooser();
    const rows = botsCatalog();
    const title = action === 'start' ? t('chooseBotToStart') : (action === 'stop' ? t('chooseBotToStop') : t('chooseBotToRestart'));
    const backdrop = document.createElement('div');
    backdrop.id='kwBotChooser';
    backdrop.className='kw-bot-modal-backdrop';
    backdrop.innerHTML = `<div class="kw-bot-modal"><div class="panel-head-inline"><div><h2>${title}</h2><div class="help-text" style="margin-top:6px">${t('botsTopChooserTitle')}</div></div><button class="btn" onclick="closeBotChooser()">${t('close')}</button></div><div class="list">${rows.length ? `${action !== 'restart' ? `<div class="row"><div class="meta"><strong>${action === 'start' ? t('botsTopStartAll') : t('botsTopStopAll')}</strong><small>${t('botsTopChooserTitle')}</small></div><button class="btn btn-primary" onclick="v38BotChooserAction('__all__','${action}')">${action === 'start' ? t('start') : t('stop')}</button></div>` : ''}${rows.map(row=>`<div class="row"><div class="meta"><strong>${esc(row.name)}</strong><small>${esc(row.subtitle || '-')} · ${row.running ? t('on') : t('off')}</small></div><div class="inline-actions"><button class="btn ${action==='start' ? 'btn-primary' : action==='stop' ? 'btn-danger' : ''}" onclick="v38BotChooserAction('${esc(row.id)}','${action}')">${action==='start' ? t('start') : action==='stop' ? t('stop') : t('restart')}</button></div></div>`).join('')}` : `<div class="empty-note">${t('botsTopNoBots')}</div>`}</div></div>`;
    backdrop.addEventListener('click', (e)=>{ if(e.target===backdrop) closeBotChooser(); });
    document.body.appendChild(backdrop);
  }
  botAction = function(action){ openBotChooser(action); };

})();


/* ===== patch v39: sync ui cleanup, startup in settings, better inventory, better refresh ===== */
(function(){
  Object.assign(T.es, {
    remove: 'Borrar',
    restore: 'Restaurar',
    refreshNowTop: 'Actualizar ahora',
    startupOptions: 'Inicio automático',
    startupOptionsHint: 'Puedes hacer que el manager arranque con Windows y, si quieres, que al abrirse arranque también el servidor.',
    startWithWindowsManager: 'Arrancar manager con Windows',
    startServerWithManager: 'Iniciar servidor al abrir el manager',
    saveStartupOptions: 'Guardar arranque',
    inventoryPlayersWithSnapshots: 'Jugadores con snapshots guardados',
    inventorySelectHint: 'Pulsa un jugador para cargar al momento su último inventario guardado o el inventario en vivo si está conectado.',
    inventoryNoSelectionYet: 'Selecciona un jugador conectado o uno del historial para ver su inventario.',
    inventoryUseOnline: 'Abrir',
    inventoryUseHistory: 'Abrir',
    inventoryLoad: 'Cargar inventario',
    inventoryReload: 'Actualizar inventario',
    refreshPlayers: 'Actualizar jugadores'
  });
  Object.assign(T.en, { remove: 'Delete', restore: 'Restore', refreshNowTop: 'Refresh now' });

  const css = document.createElement('style');
  css.textContent = `
    .card, .panel, .stat, .hero, .table tr, .btn, .small-btn, .kw-player-row, .kw-dark-select { transition: transform .18s ease, box-shadow .22s ease, border-color .22s ease, background .22s ease, opacity .22s ease; }
    .card:hover, .panel:hover { box-shadow: 0 10px 30px rgba(0,0,0,.22), 0 0 0 1px rgba(120,180,255,.08) inset; }
    .btn:hover, .small-btn:hover { transform: translateY(-1px); }
    .kw-player-row{display:flex;justify-content:space-between;align-items:center;gap:10px;width:100%;padding:12px 14px;border-radius:16px;border:1px solid rgba(255,255,255,.08);background:rgba(8,18,34,.55);color:#eef4ff;text-align:left;cursor:pointer;margin-bottom:8px}
    .kw-player-row:hover,.kw-player-row.active{border-color:rgba(110,170,255,.35);background:linear-gradient(180deg, rgba(30,55,95,.48), rgba(9,20,38,.72));box-shadow:0 0 0 1px rgba(110,170,255,.12) inset}
    .kw-player-row small{display:block;color:#a9b8d0;overflow-wrap:anywhere}
    .kw-player-grid{display:grid;grid-template-columns:1fr 1.2fr;gap:18px}
    .kw-player-list-wrap{max-height:520px;overflow:auto;padding-right:6px}
    .kw-startup-settings{margin-top:18px}
    .kw-dark-select, .kw-dark-select option{background:#0c1730;color:#eef4ff}
    .kw-startup-card{display:none !important}
    .kw-top-status-grid{display:grid;grid-template-columns:repeat(7,minmax(130px,1fr));gap:14px;margin:14px 0 2px}
    .kw-top-status-grid .stat{min-height:90px;display:flex;flex-direction:column;justify-content:center}
    .kw-top-status-grid .stat small{margin-bottom:6px;display:block;letter-spacing:.04em;text-transform:uppercase;color:#b6c3da}
    .kw-top-status-grid .stat strong{font-size:1.05rem;line-height:1.35}
    @media (max-width: 1180px){ .kw-player-grid{grid-template-columns:1fr} .kw-top-status-grid{grid-template-columns:repeat(2,minmax(140px,1fr));} }
  `;
  document.head.appendChild(css);

  function stripUiVersionText(){
    document.querySelectorAll('#eyebrow, h1, h2, h3, .help-text, .badge, .small-btn, .btn, .brand-title, .brand-subtitle, .menu button, .menu a, .hero, .card, .panel, label, span, div').forEach(el=>{
      if(el && el.childElementCount===0 && el.textContent && /UI v\d+/i.test(el.textContent)){
        el.textContent = el.textContent.replace(/\s*[·\-]\s*UI v\d+/ig,'').replace(/UI v\d+/ig,'').trim();
      }
    });
  }

  function startupCardHtml(){
    const cfg = (state.state && state.state.config) || {};
    return `<div class="card panel kw-startup-settings"><h2>${t('startupOptions')}</h2><div class="help-text" style="margin-top:6px">${t('startupOptionsHint')}</div><div class="inline-actions wrap-actions" style="margin-top:14px"><label class="kw-check-chip"><input id="startupManagerWindows" type="checkbox" ${cfg.start_with_windows_manager ? 'checked' : ''}><span>${t('startWithWindowsManager')}</span></label><label class="kw-check-chip"><input id="startupServerWithManager" type="checkbox" ${cfg.start_server_with_manager ? 'checked' : ''}><span>${t('startServerWithManager')}</span></label><button class="btn btn-primary" type="button" onclick="saveStartupFlags()">${t('saveStartupOptions')}</button></div></div>`;
  }

  const _saveStartupFlagsPrev = window.saveStartupFlags;
  window.saveStartupFlags = async function(){
    try {
      const payload = {
        start_with_windows_manager: !!document.getElementById('startupManagerWindows')?.checked,
        start_server_with_manager: !!document.getElementById('startupServerWithManager')?.checked
      };
      const res = await api('/api/config/save', 'POST', payload);
      toast(res.message || t('settingsSaved'));
      await refreshState(true);
      go('settings');
    } catch(err){ toast(err.message, true); }
  };

  const _refreshNowPrev = refreshNow;
  refreshNow = async function(ev){
    try{
      if(ev && ev.preventDefault) ev.preventDefault();
      if(ev && ev.stopPropagation) ev.stopPropagation();
      await refreshState(false);
      if (['players','inventory','moderation'].includes(state.section)) await refreshPlayers(false);
      if (state.section === 'backups') await loadBackups(false);
      if (state.section === 'serverconfig') await loadXmlAll();
      render(true);
    } catch(err){ toast(err.message, true); }
    return false;
  };

  const _renderPrevV39 = render;
  render = function(preserveScroll=false){
    _renderPrevV39(preserveScroll);
    stripUiVersionText();
    const btn = document.getElementById('btnManualRefreshTop');
    if(btn){ btn.type='button'; btn.textContent=t('refreshNowTop'); btn.onclick = (e)=>refreshNow(e); }
    const backupBtn = document.getElementById('btnBackupTop'); if(backupBtn) backupBtn.remove();
    if(state.section === 'dashboard'){
      document.querySelectorAll('.kw-startup-card,.kw-startup-settings').forEach(el=>el.remove());
    }
  };

  function currentInvPlayer(){
    if (state.historySelectedKey && state.playerProfile?.record && state.playerProfile.record.key === state.historySelectedKey) return historyPlayerFromRecord(state.playerProfile.record);
    return selectedPlayer() || historyPlayerFromRecord(state.playerProfile?.record || null);
  }

  window.v39PickOnline = async function(idx){
    state.historySelectedKey='';
    selectPlayer(idx);
    await loadPlayerProfile(true);
    await loadPlayerInventory(true);
    render(true);
  };
  window.v39PickHistory = async function(key){
    state.historySelectedKey=key || '';
    state.selectedPlayerIndex = null;
    await loadPlayerProfile(true);
    await loadPlayerInventory(true);
    render(true);
  };

  views.inventory = function(){
    const online = state.state?.players_cache || [];
    const historyRows = (state.playerHistoryList || []).filter(row => Number(row.snapshot_count || 0) > 0);
    const current = currentInvPlayer();
    return `<div class="grid">
      <div class="card panel">
        <div class="panel-head-inline"><div><h2>${t('inventoryOnlineOfflineTitle')}</h2><div class="help-text" style="margin-top:6px">${t('inventorySelectHint')}</div></div><div class="inline-actions wrap-actions"><button class="btn" type="button" onclick="refreshPlayers()">${t('refreshPlayers')}</button><button class="btn" type="button" onclick="loadPlayersHistoryList(false)">${t('refresh')}</button></div></div>
        <div class="kw-player-grid">
          <div>
            <h3>${t('playersOnline')}</h3>
            <div class="kw-player-list-wrap">${online.length ? online.map((p, idx)=>`<button class="kw-player-row ${!state.historySelectedKey && state.selectedPlayerIndex===idx ? 'active':''}" type="button" onclick="v39PickOnline(${idx})"><span><strong>${escapeHtml(playerDisplayName(p))}</strong><small>${escapeHtml(playerSteamText(p))}</small></span><span class="badge ok">${t('statusOnline')}</span></button>`).join('') : `<div class="empty-note">${t('inventoryNoOnlinePlayers')}</div>`}</div>
          </div>
          <div>
            <h3>${t('inventoryPlayersWithSnapshots')}</h3>
            <div class="kw-player-list-wrap">${historyRows.length ? historyRows.map(row=>`<button class="kw-player-row ${state.historySelectedKey===row.key ? 'active':''}" type="button" onclick="v39PickHistory('${String(row.key || '').replace(/'/g, "\\'")}')"><span><strong>${escapeHtml(row.primary_name || '-')}</strong><small>${escapeHtml(historyIdText(row))}</small></span><span class="badge default">${escapeHtml(String(row.snapshot_count || 0))}</span></button>`).join('') : `<div class="empty-note">${t('inventoryNoHistoryCandidates')}</div>`}</div>
          </div>
        </div>
      </div>
      <div class="card panel">
        <div class="panel-head-inline"><div><h2>${t('inventoryPanelTitle')}</h2><div class="help-text" style="margin-top:6px">${t('inventoryPanelText')}</div></div><div class="inline-actions wrap-actions"><button class="btn" type="button" onclick="go('players')">${t('players')}</button><button class="btn" type="button" onclick="go('moderation')">${t('moderation')}</button><button class="btn btn-primary" type="button" onclick="loadPlayerInventory()">${currentInventoryData() ? t('inventoryReload') : t('inventoryLoad')}</button></div></div>
        ${playerInventoryCard(current)}
      </div>
    </div>`;
  };


  if (!window.__kwDashboardRefreshV39) {
    window.__kwDashboardRefreshV39 = setInterval(async ()=>{
      try {
        if (document.hidden) return;
        if (!state || !state.section) return;
        if (['dashboard','inventory','moderation'].includes(state.section)) {
          await refreshState(true);
          if (state.section === 'inventory' || state.section === 'moderation') {
            await loadPlayersHistoryList(true);
            await loadPlayerProfile(true);
          }
          render(true);
        }
      } catch(_){}
    }, 5000);
  }

  const _viewsModerationPrev = views.moderation;
  views.moderation = function(){
    const html = _viewsModerationPrev ? _viewsModerationPrev() : '';
    return html.replace(/<select id="moderationPlayerPicker"/g,'<select id="moderationPlayerPicker" class="kw-dark-select"').replace(/<option /g,'<option style="background:#0c1730;color:#eef4ff" ');
  };
})();



/* ===== KW final cleanup: remove external bot + web map from UI ===== */
(function(){
  function kwNoBotMapCatalogs(){
    try{
      if (Array.isArray(window.KW_SECTION_OPTIONS)) {
        window.KW_SECTION_OPTIONS = window.KW_SECTION_OPTIONS.filter(k => !['discordbot','liveMap','openMap','__map__'].includes(String(k)));
      }
      if (window.authState) {
        if (Array.isArray(authState.sections_catalog)) {
          authState.sections_catalog = authState.sections_catalog.filter(k => !['discordbot','liveMap','openMap','__map__'].includes(String(k)));
        }
        if (Array.isArray(authState.actions_catalog)) {
          authState.actions_catalog = authState.actions_catalog.filter(r => {
            const key = String((r && r.key) || '');
            return !/^discordbot\./i.test(key) && key !== 'map.open';
          });
        }
      }
    }catch(_){}
  }

  const _kwCanAccessSection = typeof canAccessSection === 'function' ? canAccessSection : null;
  if (_kwCanAccessSection) {
    canAccessSection = function(section){
      if (String(section) === 'discordbot') return false;
      return _kwCanAccessSection.apply(this, arguments);
    };
  }

  const _kwEnsureAllowed = typeof ensureAllowed === 'function' ? ensureAllowed : null;
  if (_kwEnsureAllowed) {
    ensureAllowed = function(section, action){
      const sec = String(section || '');
      const act = String(action || '');
      if (sec === 'discordbot' || /^discordbot\./i.test(act) || act === 'map.open') return false;
      return _kwEnsureAllowed.apply(this, arguments);
    };
  }

  menuLabel = function(key){
    const map = {
      dashboard:'generalStatus',
      server:'logsTitle',
      console:'console',
      players:'players',
      inventory:'inventory',
      moderation:'moderation',
      backups:'backups',
      tasks:'scheduledTasks',
      serverconfig:'serverconfig',
      settings:'settings',
      notifications:'notifications',
      access:'access',
      helpdocs:'helpGuide'
    };
    return t(map[key] || key);
  };

  openExternalMap = function(){ return false; };

  buildMenu = function(){
    kwNoBotMapCatalogs();
    const ordered = ['dashboard','server','console','players','inventory','moderation','backups','tasks','serverconfig','settings','notifications','access'];
    const visibleKeys = ordered.filter(key => typeof canAccessSection === 'function' ? canAccessSection(key) : true);
    if ((typeof canAccessSection === 'function' ? canAccessSection('helpdocs') : true) && !visibleKeys.includes('helpdocs')) visibleKeys.push('helpdocs');
    if (!visibleKeys.includes(state.section)) state.section = visibleKeys[0] || 'dashboard';
    $('menu').innerHTML = visibleKeys.map(key => {
      return `<button data-section="${key}" class="${state.section === key ? 'active' : ''}" onclick="go('${key}')"><span class="menu-icon" aria-hidden="true"></span><span class="menu-label">${menuLabel(key)}</span></button>`;
    }).join('');
    if ($('sidebarFooter')) {
      $('sidebarFooter').innerHTML = authState.auth_enabled && authState.logged_in
        ? `<button data-section="logout" onclick="panelLogout()"><span class="menu-icon" aria-hidden="true"></span><span class="menu-label">${t('logoutButton')}</span></button>`
        : '';
    }
  };

  function removeLabelField(rx){
    document.querySelectorAll('.field').forEach(field=>{
      const label = field.querySelector('label');
      const txt = (label ? label.textContent : field.textContent || '').trim();
      if (rx.test(txt)) field.remove();
    });
  }

  function removeLabelGridPair(rx){
    document.querySelectorAll('.label-grid').forEach(grid=>{
      const children = Array.from(grid.children);
      for (let i=0;i<children.length;i+=2){
        const a = children[i], b = children[i+1];
        const txt = ((a && a.textContent) || '').trim();
        if (rx.test(txt)) { if (a) a.remove(); if (b) b.remove(); }
      }
    });
  }

  function kwUiCleanup(){
    kwNoBotMapCatalogs();
    if (state && state.section === 'discordbot') state.section = 'dashboard';

    document.querySelectorAll('[data-section="discordbot"], [data-section="openMap"]').forEach(el=>el.remove());
    document.querySelectorAll('[onclick*="openExternalMap"]').forEach(el=>el.remove());

    document.querySelectorAll('.stat, .stat.card, .top-status-card').forEach(card=>{
      const txt = (card.textContent || '').toLowerCase().replace(/\s+/g,' ');
      if (txt.includes('bot externo') || txt.includes('external bot') || txt === 'bot' || txt.includes('web map') || txt.includes('mapa web')) {
        card.remove();
      }
    });

    document.querySelectorAll('.btn, .small-btn').forEach(btn=>{
      const txt = (btn.textContent || '').toLowerCase().trim();
      if (txt.includes('abrir mapa web') || txt.includes('open web map') || txt === 'iniciar bot' || txt === 'parar bot' || txt === 'start bot' || txt === 'stop bot') {
        btn.remove();
      }
    });

    removeLabelField(/^(bot externo|external bot|url del mapa web externo \(opcional\)|web map url|url base api inventario \/ webmap|inventory api \/ webmap url|usuario api inventario|inventory api user|contraseña api inventario|inventory api password|bot token discord|discord bot token)$/i);
    removeLabelGridPair(/^(bot externo|external bot|mapa web|web map)$/i);

    document.querySelectorAll('.card.panel, .card, .kw-help-box').forEach(panel=>{
      const head = panel.querySelector('h2, h3');
      const txt = ((head && head.textContent) || '').trim().toLowerCase();
      if (txt === 'bot externo' || txt === 'external bot' || txt === 'mapa web externo' || txt === 'web map' || txt === 'mapa web') {
        panel.remove();
      }
    });
  }

  const _kwRender = typeof render === 'function' ? render : null;
  if (_kwRender) {
    render = function(preserve){
      const out = _kwRender.apply(this, arguments);
      setTimeout(kwUiCleanup, 0);
      return out;
    };
  }
  const _kwRefreshState = typeof refreshState === 'function' ? refreshState : null;
  if (_kwRefreshState) {
    refreshState = async function(){
      const out = await _kwRefreshState.apply(this, arguments);
      setTimeout(kwUiCleanup, 0);
      return out;
    };
  }
  const _kwGo = typeof go === 'function' ? go : null;
  if (_kwGo) {
    go = function(section){
      if (String(section) === 'discordbot') section = 'dashboard';
      const out = _kwGo.apply(this, [section]);
      setTimeout(kwUiCleanup, 0);
      return out;
    };
  }

  setTimeout(kwUiCleanup, 0);
  setInterval(kwUiCleanup, 1200);
})();



(function(){
  Object.assign(T.es, {
    instances: 'Instancias',
    instancesTitle: 'Instancias del servidor',
    instancesSubtitle: 'Crea perfiles separados, cada uno con su propia configuración, datos y rutas. Puedes arrancar varios servidores a la vez seleccionando una instancia distinta y lanzándola desde el mismo kit.',
    activeInstance: 'Instancia activa',
    instanceRootFolder: 'Carpeta raíz para nuevos servidores',
    saveInstanceRoot: 'Guardar carpeta raíz',
    createInstance: 'Nueva instancia',
    duplicateInstance: 'Duplicar activa',
    instanceName: 'Nombre de la instancia',
    instanceServerName: 'Servidor',
    instanceFolder: 'Carpeta servidor',
    instanceExecutable: 'Ejecutable',
    instanceTheme: 'Tema',
    openInstance: 'Abrir',
    renameInstance: 'Renombrar',
    deleteInstance: 'Borrar',
    instanceStart: 'Iniciar',
    instanceStop: 'Parar',
    instanceRestart: 'Reiniciar',
    instanceRunning: 'En marcha',
    instanceStopped: 'Parado',
    noInstancesYet: 'Todavía no hay instancias.',
    createInstancePrompt: 'Nombre de la nueva instancia',
    duplicateInstancePrompt: 'Nombre para la copia',
    renameInstancePrompt: 'Nuevo nombre para la instancia',
    deleteInstanceConfirm: '¿Seguro que quieres borrar esta instancia? El servidor de esa instancia debe estar parado.',
    switchInstanceConfirm: '¿Cambiar a esta instancia? Se cargará su configuración y sus datos en el panel.',
    instanceRootHint: 'Opcional. Si la rellenas, las nuevas instancias crearán sus carpetas base dentro de esa ruta.',
    multiInstanceHelpTitle: 'Multiinstancia',
    multiInstanceHelpText: 'Cada instancia guarda su propia configuración, inventarios, permisos, backups y tareas. Para arrancar varios servidores, crea varias instancias, configura cada una y ve iniciándolas una por una. El panel completo muestra siempre la instancia activa.',
    instanceSaved: 'Instancias actualizadas.',
    noActiveInstance: 'Sin instancia activa',
    createFirstInstance: 'Crear primera instancia',
    instanceCreateHelp: 'Al crear una instancia se descargan los archivos del servidor dedicado desde SteamCMD y se deja una carpeta propia para ese servidor.',
    instanceDownloadEnabled: 'Descargar archivos del servidor desde Steam',
    instanceNamePlaceholder: 'Ejemplo: PvE, PvP, Eventos',
    instanceCreateNow: 'Crear instancia ahora',
    instanceOpenManager: 'Abrir gestor de instancias',
    instanceCreateFirstHint: 'Todavía no hay instancias. Crea la primera y el kit dejará una carpeta y configuración separadas para ese servidor.',
    instanceCreateSuccess: 'Instancia creada correctamente.',
    instanceCreateFailed: 'No se pudo crear la instancia.'
  });
  Object.assign(T.en, {
    instances: 'Instances',
    instancesTitle: 'Server instances',
    instancesSubtitle: 'Create separate profiles with their own configuration, data and paths. You can run several servers at once by selecting a different instance and starting it from the same kit.',
    activeInstance: 'Active instance',
    instanceRootFolder: 'Root folder for new servers',
    saveInstanceRoot: 'Save root folder',
    createInstance: 'New instance',
    duplicateInstance: 'Duplicate active',
    instanceName: 'Instance name',
    instanceServerName: 'Server',
    instanceFolder: 'Server folder',
    instanceExecutable: 'Executable',
    instanceTheme: 'Theme',
    openInstance: 'Open',
    renameInstance: 'Rename',
    deleteInstance: 'Delete',
    instanceStart: 'Start',
    instanceStop: 'Stop',
    instanceRestart: 'Restart',
    instanceRunning: 'Running',
    instanceStopped: 'Stopped',
    noInstancesYet: 'There are no instances yet.',
    createInstancePrompt: 'New instance name',
    duplicateInstancePrompt: 'Name for the copy',
    renameInstancePrompt: 'New instance name',
    deleteInstanceConfirm: 'Delete this instance? Its server must be stopped first.',
    switchInstanceConfirm: 'Switch to this instance? Its configuration and data will be loaded into the panel.',
    instanceRootHint: 'Optional. If set, new instances will create their base folders inside that path.',
    multiInstanceHelpTitle: 'Multi-instance',
    multiInstanceHelpText: 'Each instance keeps its own configuration, inventories, permissions, backups and tasks. To run several servers, create several instances, configure each one and start them one by one. The full panel always shows the active instance.',
    instanceSaved: 'Instances updated.',
    noActiveInstance: 'No active instance',
    createFirstInstance: 'Create first instance',
    instanceCreateHelp: 'When you create an instance, the kit downloads the dedicated server files through SteamCMD and prepares a separate folder for that server.',
    instanceDownloadEnabled: 'Download server files from Steam',
    instanceNamePlaceholder: 'Example: PvE, PvP, Events',
    instanceCreateNow: 'Create instance now',
    instanceOpenManager: 'Open instance manager',
    instanceCreateFirstHint: 'There are no instances yet. Create the first one and the kit will prepare a separate folder and configuration for that server.',
    instanceCreateSuccess: 'Instance created successfully.',
    instanceCreateFailed: 'The instance could not be created.'
  });

  const esc = v => String(v ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));

  function kwEnsureInstanceStyles(){
    if(document.getElementById('kw-v46-instance-styles')) return;
    const style = document.createElement('style');
    style.id = 'kw-v46-instance-styles';
    style.textContent = `
      .kw-instance-strip{margin-top:12px;padding:14px 18px;border-radius:22px;background:rgba(7,28,63,.88);border:1px solid rgba(90,168,255,.16);display:flex;gap:14px;align-items:center;justify-content:space-between;flex-wrap:wrap}
      .kw-instance-strip .kw-left{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
      .kw-instance-strip .kw-pill{display:inline-flex;align-items:center;gap:8px;padding:9px 12px;border-radius:999px;background:rgba(85,167,255,.12);border:1px solid rgba(85,167,255,.24);font-weight:700}
      .kw-instance-strip select,.kw-instance-strip input{border:1px solid rgba(112,149,196,.24);background:rgba(7,22,43,.88);color:var(--text);border-radius:14px;padding:10px 12px;min-width:220px}
      .kw-instances-grid{display:grid;gap:18px}
      .kw-instance-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:16px}
      .kw-instance-card{padding:18px;border-radius:22px;background:rgba(8,24,51,.92);border:1px solid rgba(90,168,255,.16)}
      .kw-instance-card h3{margin:0 0 10px;font-size:22px;display:flex;align-items:center;justify-content:space-between;gap:10px}
      .kw-instance-meta{display:grid;grid-template-columns:140px 1fr;gap:8px 12px;font-size:14px}
      .kw-instance-meta div:nth-child(odd){color:var(--muted)}
      .kw-instance-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}
      .kw-instance-badge{display:inline-flex;align-items:center;gap:8px;padding:7px 10px;border-radius:999px;border:1px solid rgba(255,255,255,.08);font-size:12px;font-weight:700}
      .kw-instance-badge.ok{background:rgba(98,183,126,.14);color:#bff4cf}
      .kw-instance-badge.off{background:rgba(240,103,103,.12);color:#ffd0d0}
      .kw-instance-top-actions{display:flex;gap:10px;flex-wrap:wrap}
      .kw-instance-muted{color:var(--muted);font-size:14px;line-height:1.45}
    `;
    document.head.appendChild(style);
  }

  function kwInstancesList(){
    return Array.isArray(state?.state?.instances_catalog) ? state.state.instances_catalog : [];
  }

  function kwActiveInstanceId(){
    return String(state?.state?.active_instance_id || '');
  }

  async function kwInstancesReload(){
    await refreshState(true);
    render(true);
    toast(t('instanceSaved'));
  }

  async function kwSelectInstance(id){
    if(!id || id === kwActiveInstanceId()) return;
    if(!window.confirm(t('switchInstanceConfirm'))) return;
    const res = await api('/api/instances/select','POST',{id});
    await refreshState(true);
    render(true);
    toast(res?.message || t('instanceSaved'));
  }
  window.kwSelectInstance = kwSelectInstance;

  async function kwSaveInstancesRoot(){
    const el = document.getElementById('kwInstancesRootFolder');
    const res = await api('/api/instances/root','POST',{folder: el ? el.value : ''});
    await refreshState(true);
    render(true);
    toast(res?.message || t('instanceSaved'));
  }
  window.kwSaveInstancesRoot = kwSaveInstancesRoot;

  async function kwCreateInstance(){
    if(state.section !== 'instances'){
      go('instances');
      setTimeout(() => {
        const input = document.getElementById('kwNewInstanceName');
        if(input) input.focus();
      }, 80);
      return;
    }
    const input = document.getElementById('kwNewInstanceName');
    const downloadEl = document.getElementById('kwDownloadServerFiles');
    const name = input ? String(input.value || '').trim() : '';
    const download_server = downloadEl ? String(downloadEl.value || '1') !== '0' : true;
    const res = await api('/api/instances/create','POST',{name, download_server});
    if(input) input.value = '';
    await refreshState(true);
    render(true);
    toast(res?.message || t('instanceCreateSuccess'));
  }
  window.kwCreateInstance = kwCreateInstance;

  async function kwDuplicateActiveInstance(){
    const source_id = kwActiveInstanceId();
    if(!source_id){
      go('instances');
      return;
    }
    const name = window.prompt(t('duplicateInstancePrompt'), '');
    if(name === null) return;
    const res = await api('/api/instances/duplicate','POST',{source_id, name});
    await refreshState(true);
    render(true);
    toast(res?.message || t('instanceSaved'));
  }
  window.kwDuplicateActiveInstance = kwDuplicateActiveInstance;

  async function kwRenameInstance(id){
    const row = kwInstancesList().find(x => String(x.id) === String(id));
    const name = window.prompt(t('renameInstancePrompt'), row ? row.name : '');
    if(name === null) return;
    const res = await api('/api/instances/update','POST',{id, name});
    await refreshState(true);
    render(true);
    toast(res?.message || t('instanceSaved'));
  }
  window.kwRenameInstance = kwRenameInstance;

  async function kwDeleteInstance(id){
    if(!window.confirm(t('deleteInstanceConfirm'))) return;
    const res = await api('/api/instances/delete','POST',{id});
    await refreshState(true);
    render(true);
    toast(res?.message || t('instanceSaved'));
  }
  window.kwDeleteInstance = kwDeleteInstance;

  async function kwInstanceServerAction(id, action){
    const res = await api('/api/instances/server-action','POST',{id, action});
    await refreshState(true);
    render(true);
    toast(res?.message || t('instanceSaved'));
  }
  window.kwInstanceServerAction = kwInstanceServerAction;

  function kwRenderInstanceStrip(){
    kwEnsureInstanceStyles();
    const main = document.querySelector('.main-area');
    if(!main) return;
    let wrap = document.getElementById('kwInstanceStrip');
    if(!wrap){
      wrap = document.createElement('div');
      wrap.id = 'kwInstanceStrip';
      const top = document.getElementById('topStatusBar');
      if(top && top.parentNode === main) top.insertAdjacentElement('afterend', wrap);
      else main.insertBefore(wrap, main.firstChild.nextSibling || null);
    }
    const list = kwInstancesList();
    const active = kwActiveInstanceId();
    const activeName = esc(state?.state?.active_instance_name || active || t('noActiveInstance'));
    wrap.className = 'kw-instance-strip';
    if(!list.length){
      wrap.innerHTML = `
        <div class="kw-left">
          <span class="kw-pill">${t('activeInstance')}: <strong>${t('noActiveInstance')}</strong></span>
          <span class="kw-instance-muted">${t('instanceCreateFirstHint')}</span>
        </div>
        <div class="kw-instance-top-actions">
          <button class="btn btn-primary" onclick="go('instances'); setTimeout(() => { const input = document.getElementById('kwNewInstanceName'); if(input) input.focus(); }, 80);">${t('createFirstInstance')}</button>
        </div>
      `;
      return;
    }
    wrap.innerHTML = `
      <div class="kw-left">
        <span class="kw-pill">${t('activeInstance')}: <strong>${activeName}</strong></span>
        <select id="kwActiveInstanceSelect" onchange="kwSelectInstance(this.value)">
          ${list.map(row => `<option value="${esc(row.id)}" ${String(row.id)===String(active)?'selected':''}>${esc(row.name)}</option>`).join('')}
        </select>
      </div>
      <div class="kw-instance-top-actions">
        <button class="btn" onclick="go('instances'); setTimeout(() => { const input = document.getElementById('kwNewInstanceName'); if(input) input.focus(); }, 80);">${t('createInstance')}</button>
        <button class="btn" onclick="kwDuplicateActiveInstance()" ${active ? '' : 'disabled'}>${t('duplicateInstance')}</button>
      </div>
    `;
  }

  const _kwPrevMenuLabelV46 = menuLabel;
  menuLabel = function(key){
    if(String(key)==='instances') return t('instances');
    return _kwPrevMenuLabelV46(key);
  };

  const _kwPrevBuildMenuV46 = buildMenu;
  buildMenu = function(){
    _kwPrevBuildMenuV46();
    const menu = document.getElementById('menu');
    if(!menu) return;
    const exists = menu.querySelector('[data-section="instances"]');
    if(exists) exists.remove();
    const btn = document.createElement('button');
    btn.setAttribute('data-section','instances');
    if(state.section === 'instances') btn.className = 'active';
    btn.onclick = () => go('instances');
    btn.innerHTML = `<span class="menu-icon" aria-hidden="true"></span><span class="menu-label">${t('instances')}</span>`;
    const first = menu.firstElementChild;
    if(first) first.insertAdjacentElement('afterend', btn);
    else menu.appendChild(btn);
  };

  views.instances = function(){
    const list = kwInstancesList();
    const active = kwActiveInstanceId();
    const rootFolder = esc(state?.state?.instances_root_folder || '');
    return `
      <div class="kw-instances-grid">
        <div class="card panel">
          <h2>${t('instancesTitle')}</h2>
          <p class="kw-instance-muted">${t('instancesSubtitle')}</p>
          <div class="input-grid" style="margin-top:14px">
            <div class="field">
              <label>${t('instanceRootFolder')}</label>
              <input id="kwInstancesRootFolder" value="${rootFolder}" placeholder="D:/KarmaWorld_Servers">
              <div class="kw-instance-muted">${t('instanceRootHint')}</div>
            </div>
            <div class="field">
              <label>&nbsp;</label>
              <div class="inline-actions">
                <button class="btn btn-primary" onclick="kwSaveInstancesRoot()">${t('saveInstanceRoot')}</button>
              </div>
            </div>
          </div>
        </div>
        <div class="card panel">
          <h2>${t('createInstance')}</h2>
          <p class="kw-instance-muted">${t('instanceCreateHelp')}</p>
          <div class="input-grid" style="margin-top:14px">
            <div class="field">
              <label>${t('instanceName')}</label>
              <input id="kwNewInstanceName" value="" placeholder="${t('instanceNamePlaceholder')}">
            </div>
            <div class="field">
              <label>${t('instanceDownloadEnabled')}</label>
              <select id="kwDownloadServerFiles">
                <option value="1" selected>${t('yes')}</option>
                <option value="0">${t('no')}</option>
              </select>
            </div>
          </div>
          <div class="inline-actions" style="margin-top:14px">
            <button class="btn btn-primary" onclick="kwCreateInstance()">${t('instanceCreateNow')}</button>
            <button class="btn" onclick="kwDuplicateActiveInstance()" ${active ? '' : 'disabled'}>${t('duplicateInstance')}</button>
          </div>
        </div>
        <div class="kw-instance-cards">
          ${list.length ? list.map(row => `
            <article class="kw-instance-card">
              <h3>
                <span>${esc(row.name)}</span>
                <span class="kw-instance-badge ${row.running ? 'ok' : 'off'}">${row.running ? t('instanceRunning') : t('instanceStopped')}</span>
              </h3>
              <div class="kw-instance-meta">
                <div>${t('activeInstance')}</div><div>${String(row.id)===String(active) ? '✓' : '-'}</div>
                <div>${t('instanceServerName')}</div><div>${esc(row.server_name || '-')}</div>
                <div>${t('instanceFolder')}</div><div>${esc(row.server_folder || '-')}</div>
                <div>${t('instanceExecutable')}</div><div>${esc(row.executable_path || '-')}</div>
                <div>${t('instanceTheme')}</div><div>${esc(row.ui_theme || '-')}</div>
                <div>${t('pid')}</div><div>${esc(row.pid || '-')}</div>
              </div>
              <div class="kw-instance-actions">
                <button class="btn btn-primary" onclick="kwSelectInstance('${esc(row.id)}')">${t('openInstance')}</button>
                <button class="btn" onclick="kwRenameInstance('${esc(row.id)}')">${t('renameInstance')}</button>
                <button class="btn" onclick="kwInstanceServerAction('${esc(row.id)}','start')">${t('instanceStart')}</button>
                <button class="btn" onclick="kwInstanceServerAction('${esc(row.id)}','restart')">${t('instanceRestart')}</button>
                <button class="btn btn-danger" onclick="kwInstanceServerAction('${esc(row.id)}','stop')">${t('instanceStop')}</button>
                <button class="btn btn-danger" onclick="kwDeleteInstance('${esc(row.id)}')">${t('deleteInstance')}</button>
              </div>
            </article>
          `).join('') : `<div class="card panel"><h3>${t('noInstancesYet')}</h3><p class="kw-instance-muted">${t('instanceCreateFirstHint')}</p></div>`}
        </div>
      </div>
    `;
  };

  const _kwPrevHelpDocsV46 = views.helpdocs;
  if(typeof _kwPrevHelpDocsV46 === 'function'){
    views.helpdocs = function(){
      return `
        <div class="card panel"><h2>${t('multiInstanceHelpTitle')}</h2><p>${t('multiInstanceHelpText')}</p></div>
        ${_kwPrevHelpDocsV46()}
      `;
    };
  }

  const _kwPrevRenderV46 = render;
  render = function(preserve){
    const out = _kwPrevRenderV46.apply(this, arguments);
    setTimeout(kwRenderInstanceStrip, 0);
    return out;
  };

  const _kwPrevRefreshStateV46 = refreshState;
  refreshState = async function(){
    const out = await _kwPrevRefreshStateV46.apply(this, arguments);
    setTimeout(kwRenderInstanceStrip, 0);
    return out;
  };

  setTimeout(kwRenderInstanceStrip, 0);
})();


/* ===== Multiinstancia V3: menú real, ajustes por instancia y controles dentro de instancias ===== */
(function(){
  Object.assign(T.es, {
    instanceSettingsOnlyTitle: 'Ajustes por instancia',
    instanceSettingsOnlyText: 'Los ajustes del servidor solo se editan dentro de una instancia seleccionada. Primero crea o selecciona una instancia desde la pestaña Instancias.',
    instanceManageNow: 'Ir a Instancias',
    instanceActiveBanner: 'Editando ajustes de la instancia activa:',
    instanceActionError: 'No se pudo completar la acción de instancia.'
  });
  Object.assign(T.en, {
    instanceSettingsOnlyTitle: 'Per-instance settings',
    instanceSettingsOnlyText: 'Server settings are only edited inside a selected instance. Create or select an instance first from the Instances tab.',
    instanceManageNow: 'Go to Instances',
    instanceActiveBanner: 'Editing settings for the active instance:',
    instanceActionError: 'The instance action could not be completed.'
  });

  function esc2(v){ return typeof escapeHtml === 'function' ? escapeHtml(v == null ? '' : String(v)) : String(v == null ? '' : v); }
  function kwInstancesList(){ return Array.isArray(state?.state?.instances_catalog) ? state.state.instances_catalog : []; }
  function kwActiveInstanceId(){ return String(state?.state?.active_instance_id || '').trim(); }
  function kwHasActiveInstance(){ return kwActiveInstanceId() !== ''; }
  function kwActiveInstanceName(){ return String(state?.state?.active_instance_name || '').trim(); }

  function removeTopServerButtons(){
    ['btnStartTop','btnRestartTop','btnStopTop'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.remove();
    });
    const wrap = document.getElementById('kwInstanceStrip');
    if (wrap) wrap.remove();
  }

  const _miV3PrevBuildMenu = buildMenu;
  buildMenu = function(){
    if (typeof kwMenuCleanup === 'function') kwMenuCleanup();
    const ordered = ['dashboard','instances','server','console','players','inventory','moderation','backups','tasks','serverconfig','settings','notifications','access'];
    const visibleKeys = ordered.filter(key => key === 'instances' ? true : (typeof canAccessSection === 'function' ? canAccessSection(key) : true));
    if ((typeof canAccessSection === 'function' ? canAccessSection('helpdocs') : true) && !visibleKeys.includes('helpdocs')) visibleKeys.push('helpdocs');
    if (!visibleKeys.includes(state.section)) state.section = visibleKeys[0] || 'dashboard';
    const menu = document.getElementById('menu');
    if (menu) {
      menu.innerHTML = visibleKeys.map(key => `<button data-section="${key}" class="${state.section === key ? 'active' : ''}" onclick="go('${key}')"><span class="menu-icon" aria-hidden="true"></span><span class="menu-label">${menuLabel(key)}</span></button>`).join('');
    }
    const footer = document.getElementById('sidebarFooter');
    if (footer) {
      footer.innerHTML = authState && authState.auth_enabled && authState.logged_in
        ? `<button data-section="logout" onclick="panelLogout()"><span class="menu-icon" aria-hidden="true"></span><span class="menu-label">${t('logoutButton')}</span></button>`
        : '';
    }
  };

  window.kwSaveInstancesRoot = async function(){
    try {
      const el = document.getElementById('kwInstancesRootFolder');
      const res = await api('/api/instances/root','POST',{folder: el ? el.value : ''});
      await refreshState(true);
      render(true);
      toast((res && res.message) || t('instanceSaved'));
    } catch (err) { toast((err && err.message) || t('instanceActionError'), true); }
  };

  window.kwCreateInstance = async function(){
    try {
      if (state.section !== 'instances') {
        go('instances');
        setTimeout(() => { const input = document.getElementById('kwNewInstanceName'); if (input) input.focus(); }, 100);
        return;
      }
      const input = document.getElementById('kwNewInstanceName');
      const downloadEl = document.getElementById('kwDownloadServerFiles');
      const name = input ? String(input.value || '').trim() : '';
      const download_server = downloadEl ? String(downloadEl.value || '1') !== '0' : true;
      const res = await api('/api/instances/create','POST',{name, download_server});
      if (input) input.value = '';
      await refreshState(true);
      render(true);
      toast((res && res.message) || t('instanceCreateSuccess'));
    } catch (err) { toast((err && err.message) || t('instanceCreateFailed'), true); }
  };

  window.kwDuplicateActiveInstance = async function(){
    try {
      const source_id = kwActiveInstanceId();
      if(!source_id){ go('instances'); return; }
      const name = window.prompt(t('duplicateInstancePrompt'), '');
      if(name === null) return;
      const res = await api('/api/instances/duplicate','POST',{source_id, name});
      await refreshState(true);
      render(true);
      toast((res && res.message) || t('instanceSaved'));
    } catch (err) { toast((err && err.message) || t('instanceActionError'), true); }
  };

  window.kwSelectInstance = async function(id){
    try {
      if(!id || id === kwActiveInstanceId()) return;
      if(!window.confirm(t('switchInstanceConfirm'))) return;
      const res = await api('/api/instances/select','POST',{id});
      await refreshState(true);
      render(true);
      toast((res && res.message) || t('instanceSaved'));
    } catch (err) { toast((err && err.message) || t('instanceActionError'), true); }
  };

  window.kwRenameInstance = async function(id){
    try {
      const row = kwInstancesList().find(x => String(x.id) === String(id));
      const name = window.prompt(t('renameInstancePrompt'), row ? row.name : '');
      if(name === null) return;
      const res = await api('/api/instances/update','POST',{id, name});
      await refreshState(true);
      render(true);
      toast((res && res.message) || t('instanceSaved'));
    } catch (err) { toast((err && err.message) || t('instanceActionError'), true); }
  };

  window.kwDeleteInstance = async function(id){
    try {
      if(!window.confirm(t('deleteInstanceConfirm'))) return;
      const res = await api('/api/instances/delete','POST',{id});
      await refreshState(true);
      render(true);
      toast((res && res.message) || t('instanceSaved'));
    } catch (err) { toast((err && err.message) || t('instanceActionError'), true); }
  };

  window.kwInstanceServerAction = async function(id, action){
    try {
      const res = await api('/api/instances/server-action','POST',{id, action});
      await refreshState(true);
      render(true);
      toast((res && res.message) || t('instanceSaved'));
    } catch (err) { toast((err && err.message) || t('instanceActionError'), true); }
  };

  const _miV3PrevSettings = views.settings;
  views.settings = function(){
    if (!kwHasActiveInstance()) {
      return `
        <div class="grid">
          <div class="card panel">
            <h2>${t('instanceSettingsOnlyTitle')}</h2>
            <p class="help-text" style="margin-top:8px">${t('instanceSettingsOnlyText')}</p>
            <div class="inline-actions" style="margin-top:16px">
              <button class="btn btn-primary" onclick="go('instances')">${t('instanceManageNow')}</button>
            </div>
          </div>
        </div>`;
    }
    const banner = `
      <div class="card panel" style="margin-bottom:14px">
        <div class="kw-pill">${t('instanceActiveBanner')} <strong>${esc2(kwActiveInstanceName() || t('noActiveInstance'))}</strong></div>
      </div>`;
    return banner + (_miV3PrevSettings ? _miV3PrevSettings() : '');
  };

  if (typeof saveSettings === 'function') {
    const _miV3PrevSaveSettings = saveSettings;
    saveSettings = async function(){
      if (!kwHasActiveInstance()) { toast(t('instanceSettingsOnlyText'), true); go('instances'); return; }
      return await _miV3PrevSaveSettings.apply(this, arguments);
    };
    window.saveSettings = saveSettings;
  }
  if (typeof saveStartupFlags === 'function') {
    const _miV3PrevSaveStartupFlags = saveStartupFlags;
    saveStartupFlags = async function(){
      if (!kwHasActiveInstance()) { toast(t('instanceSettingsOnlyText'), true); go('instances'); return; }
      return await _miV3PrevSaveStartupFlags.apply(this, arguments);
    };
    window.saveStartupFlags = saveStartupFlags;
  }

  views.instances = function(){
    const list = kwInstancesList();
    const active = kwActiveInstanceId();
    const rootFolder = esc2(state?.state?.instances_root_folder || '');
    return `
      <div class="kw-instances-grid">
        <div class="card panel">
          <h2>${t('instancesTitle')}</h2>
          <p class="kw-instance-muted">${t('instancesSubtitle')}</p>
          <div class="input-grid" style="margin-top:14px">
            <div class="field">
              <label>${t('instanceRootFolder')}</label>
              <input id="kwInstancesRootFolder" value="${rootFolder}" placeholder="D:/KarmaWorld_Servers">
              <div class="kw-instance-muted">${t('instanceRootHint')}</div>
            </div>
            <div class="field">
              <label>&nbsp;</label>
              <div class="inline-actions">
                <button class="btn btn-primary" onclick="kwSaveInstancesRoot()">${t('saveInstanceRoot')}</button>
              </div>
            </div>
          </div>
        </div>
        <div class="card panel">
          <h2>${t('createInstance')}</h2>
          <p class="kw-instance-muted">${t('instanceCreateHelp')}</p>
          <div class="input-grid" style="margin-top:14px">
            <div class="field">
              <label>${t('instanceName')}</label>
              <input id="kwNewInstanceName" value="" placeholder="${t('instanceNamePlaceholder')}">
            </div>
            <div class="field">
              <label>${t('instanceDownloadEnabled')}</label>
              <select id="kwDownloadServerFiles">
                <option value="1" selected>${t('yes')}</option>
                <option value="0">${t('no')}</option>
              </select>
            </div>
          </div>
          <div class="inline-actions" style="margin-top:14px">
            <button class="btn btn-primary" onclick="kwCreateInstance()">${t('instanceCreateNow')}</button>
            <button class="btn" onclick="kwDuplicateActiveInstance()" ${active ? '' : 'disabled'}>${t('duplicateInstance')}</button>
          </div>
        </div>
        <div class="kw-instance-cards">
          ${list.length ? list.map(row => `
            <article class="kw-instance-card ${String(row.id)===String(active) ? 'is-active' : ''}">
              <h3>
                <span>${esc2(row.name)}</span>
                <span class="kw-instance-badge ${row.running ? 'ok' : 'off'}">${row.running ? t('instanceRunning') : t('instanceStopped')}</span>
              </h3>
              <div class="kw-instance-meta">
                <div>${t('activeInstance')}</div><div>${String(row.id)===String(active) ? '✓' : '-'}</div>
                <div>${t('instanceServerName')}</div><div>${esc2(row.server_name || '-')}</div>
                <div>${t('instanceFolder')}</div><div>${esc2(row.server_folder || '-')}</div>
                <div>${t('instanceExecutable')}</div><div>${esc2(row.executable_path || '-')}</div>
                <div>${t('instanceTheme')}</div><div>${esc2(row.ui_theme || '-')}</div>
                <div>${t('pid')}</div><div>${esc2(row.pid || '-')}</div>
              </div>
              <div class="kw-instance-actions">
                <button class="btn btn-primary" onclick="kwSelectInstance('${esc2(row.id)}')">${t('openInstance')}</button>
                <button class="btn" onclick="kwRenameInstance('${esc2(row.id)}')">${t('renameInstance')}</button>
                <button class="btn" onclick="kwInstanceServerAction('${esc2(row.id)}','start')">${t('instanceStart')}</button>
                <button class="btn" onclick="kwInstanceServerAction('${esc2(row.id)}','restart')">${t('instanceRestart')}</button>
                <button class="btn btn-danger" onclick="kwInstanceServerAction('${esc2(row.id)}','stop')">${t('instanceStop')}</button>
                <button class="btn btn-danger" onclick="kwDeleteInstance('${esc2(row.id)}')">${t('deleteInstance')}</button>
              </div>
            </article>
          `).join('') : `<div class="card panel"><h3>${t('noInstancesYet')}</h3><p class="kw-instance-muted">${t('instanceCreateFirstHint')}</p></div>`}
        </div>
      </div>`;
  };

  const _miV3PrevRender = render;
  render = function(){
    const out = _miV3PrevRender.apply(this, arguments);
    setTimeout(removeTopServerButtons, 0);
    return out;
  };
  const _miV3PrevRefreshState = refreshState;
  refreshState = async function(){
    const out = await _miV3PrevRefreshState.apply(this, arguments);
    setTimeout(removeTopServerButtons, 0);
    return out;
  };
  const _miV3PrevRenderStaticTexts = renderStaticTexts;
  renderStaticTexts = function(){
    const out = _miV3PrevRenderStaticTexts.apply(this, arguments);
    removeTopServerButtons();
    return out;
  };

  Object.assign(T.es, {
    instanceRootBrowse: 'Elegir carpeta',
    instanceRefreshList: 'Refrescar instancias',
    instanceInstallStatus: 'Descarga',
    instanceInstallIdle: 'Sin descarga',
    instanceInstallQueued: 'En cola',
    instanceInstallInstalling: 'Descargando',
    instanceInstallReady: 'Lista',
    instanceInstallError: 'Error',
    instanceInstallUnknown: 'Desconocido',
    instanceBackgroundDownloadStarted: 'Instancia creada. La descarga del servidor continúa en segundo plano.',
    instanceRootBrowseTitle: 'Selecciona la carpeta raíz para nuevas instancias',
    instanceCreateWorking: 'Creando la instancia...',
    instanceRefreshing: 'Actualizando instancias...',
    instanceInstallProgress: 'Progreso',
    instanceInstallTarget: 'Descargando en',
    instanceInstallProgressNone: 'Esperando progreso...'
  });
  Object.assign(T.en, {
    instanceRootBrowse: 'Choose folder',
    instanceRefreshList: 'Refresh instances',
    instanceInstallStatus: 'Download',
    instanceInstallIdle: 'No download',
    instanceInstallQueued: 'Queued',
    instanceInstallInstalling: 'Downloading',
    instanceInstallReady: 'Ready',
    instanceInstallError: 'Error',
    instanceInstallUnknown: 'Unknown',
    instanceBackgroundDownloadStarted: 'Instance created. Server download continues in the background.',
    instanceRootBrowseTitle: 'Select the root folder for new instances',
    instanceCreateWorking: 'Creating instance...',
    instanceRefreshing: 'Refreshing instances...',
    instanceInstallProgress: 'Progress',
    instanceInstallTarget: 'Downloading to',
    instanceInstallProgressNone: 'Waiting for progress...'
  });

  function kwInstallStatusLabel(status){
    const map = {
      idle: t('instanceInstallIdle'),
      queued: t('instanceInstallQueued'),
      installing: t('instanceInstallInstalling'),
      ready: t('instanceInstallReady'),
      error: t('instanceInstallError')
    };
    return map[String(status || '').trim().toLowerCase()] || t('instanceInstallUnknown');
  }

  function kwInstallBadgeClass(status){
    const s = String(status || '').trim().toLowerCase();
    if (s === 'ready') return 'ok';
    if (s === 'error') return 'off';
    return '';
  }


  function kwInstallProgressValue(row){
    const n = Number(row && row.install_progress);
    if (!Number.isFinite(n)) return 0;
    return Math.max(0, Math.min(100, Math.round(n)));
  }

  async function kwBrowseInstancesRoot(){
    try {
      await browseField('kwInstancesRootFolder', 'folder', t('instanceRootBrowseTitle'));
    } catch (err) {
      toast((err && err.message) || t('error'), true);
    }
  }
  window.kwBrowseInstancesRoot = kwBrowseInstancesRoot;

  const _miV4PrevKwCreateInstance = window.kwCreateInstance;
  window.kwCreateInstance = async function(){
    const btn = document.getElementById('kwCreateInstanceBtn');
    const oldText = btn ? btn.textContent : '';
    try {
      if (btn){ btn.disabled = true; btn.textContent = t('instanceCreateWorking'); }
      if (typeof _miV4PrevKwCreateInstance === 'function') {
        await _miV4PrevKwCreateInstance();
        toast(t('instanceBackgroundDownloadStarted'));
      }
    } catch (err) {
      toast((err && err.message) || t('instanceCreateFailed'), true);
    } finally {
      if (btn){ btn.disabled = false; btn.textContent = oldText || t('instanceCreateNow'); }
    }
  };

  window.kwRefreshInstances = async function(){
    try {
      toast(t('instanceRefreshing'));
      await refreshState(true);
      render(true);
    } catch (err) {
      toast((err && err.message) || t('instanceActionError'), true);
    }
  };

  views.instances = function(){
    const list = kwInstancesList();
    const active = kwActiveInstanceId();
    const rootFolder = esc2(state?.state?.instances_root_folder || '');
    return `
      <div class="kw-instances-grid">
        <div class="card panel">
          <h2>${t('instancesTitle')}</h2>
          <p class="kw-instance-muted">${t('instancesSubtitle')}</p>
          <div class="input-grid" style="margin-top:14px">
            <div class="field">
              <label>${t('instanceRootFolder')}</label>
              <div class="input-with-btn">
                <input id="kwInstancesRootFolder" value="${rootFolder}" placeholder="D:/KarmaWorld_Servers">
                <button class="btn" type="button" onclick="kwBrowseInstancesRoot()">${t('instanceRootBrowse')}</button>
              </div>
              <div class="kw-instance-muted">${t('instanceRootHint')}</div>
            </div>
            <div class="field">
              <label>&nbsp;</label>
              <div class="inline-actions">
                <button class="btn btn-primary" onclick="kwSaveInstancesRoot()">${t('saveInstanceRoot')}</button>
                <button class="btn" onclick="kwRefreshInstances()">${t('instanceRefreshList')}</button>
              </div>
            </div>
          </div>
        </div>
        <div class="card panel">
          <h2>${t('createInstance')}</h2>
          <p class="kw-instance-muted">${t('instanceCreateHelp')}</p>
          <div class="input-grid" style="margin-top:14px">
            <div class="field">
              <label>${t('instanceName')}</label>
              <input id="kwNewInstanceName" value="" placeholder="${t('instanceNamePlaceholder')}">
            </div>
            <div class="field">
              <label>${t('instanceDownloadEnabled')}</label>
              <select id="kwDownloadServerFiles">
                <option value="1" selected>${t('yes')}</option>
                <option value="0">${t('no')}</option>
              </select>
            </div>
          </div>
          <div class="inline-actions" style="margin-top:14px">
            <button id="kwCreateInstanceBtn" class="btn btn-primary" onclick="kwCreateInstance()">${t('instanceCreateNow')}</button>
            <button class="btn" onclick="kwDuplicateActiveInstance()" ${active ? '' : 'disabled'}>${t('duplicateInstance')}</button>
          </div>
        </div>
        <div class="kw-instance-cards">
          ${list.length ? list.map(row => {
            const pct = kwInstallProgressValue(row);
            const target = esc2(row.install_target || row.server_folder || '-');
            const progressText = pct > 0 ? `${pct}%` : t('instanceInstallProgressNone');
            return `
            <article class="kw-instance-card ${String(row.id)===String(active) ? 'is-active' : ''}">
              <h3>
                <span>${esc2(row.name)}</span>
                <span class="kw-instance-badge ${row.running ? 'ok' : 'off'}">${row.running ? t('instanceRunning') : t('instanceStopped')}</span>
              </h3>
              <div class="kw-instance-meta">
                <div>${t('activeInstance')}</div><div>${String(row.id)===String(active) ? '✓' : '-'}</div>
                <div>${t('instanceInstallStatus')}</div><div><span class="kw-instance-badge ${kwInstallBadgeClass(row.install_status)}">${kwInstallStatusLabel(row.install_status)}</span> ${esc2(row.install_message || '')}</div>
                <div>${t('instanceInstallProgress')}</div><div><div class="kw-install-progress"><span style="width:${pct}%"></span></div><div class="kw-instance-muted" style="margin-top:6px">${progressText}</div></div>
                <div>${t('instanceInstallTarget')}</div><div>${target}</div>
                <div>${t('instanceServerName')}</div><div>${esc2(row.server_name || '-')}</div>
                <div>${t('instanceFolder')}</div><div>${esc2(row.server_folder || '-')}</div>
                <div>${t('instanceExecutable')}</div><div>${esc2(row.executable_path || '-')}</div>
                <div>${t('instanceTheme')}</div><div>${esc2(row.ui_theme || '-')}</div>
                <div>${t('pid')}</div><div>${row.running ? esc2(row.pid || '-') : '-'}</div>
              </div>
              <div class="kw-instance-actions">
                <button class="btn btn-primary" onclick="kwSelectInstance('${esc2(row.id)}')">${t('openInstance')}</button>
                <button class="btn" onclick="kwRenameInstance('${esc2(row.id)}')">${t('renameInstance')}</button>
                <button class="btn" onclick="kwInstanceServerAction('${esc2(row.id)}','start')">${t('instanceStart')}</button>
                <button class="btn" onclick="kwInstanceServerAction('${esc2(row.id)}','restart')">${t('instanceRestart')}</button>
                <button class="btn btn-danger" onclick="kwInstanceServerAction('${esc2(row.id)}','stop')">${t('instanceStop')}</button>
                <button class="btn btn-danger" onclick="kwDeleteInstance('${esc2(row.id)}')">${t('deleteInstance')}</button>
              </div>
            </article>`;
          }).join('') : `<div class="card panel"><h3>${t('noInstancesYet')}</h3><p class="kw-instance-muted">${t('instanceCreateFirstHint')}</p></div>`}
        </div>
      </div>`;
  };

  const miV4Style = document.createElement('style');
  miV4Style.id = 'kw-v47-scroll-fix';
  miV4Style.textContent = `
    html, body { height: 100%; overflow: hidden; }
    .app-shell { height: 100vh; min-height: 100vh; }
    .sidebar { overflow-y: auto; min-height: 0; }
    .main-area { height: 100vh; overflow-y: auto; min-height: 0; padding-bottom: 36px; }
    .kw-instance-card .kw-instance-badge { vertical-align: middle; }
    .kw-install-progress{height:14px;border-radius:999px;background:rgba(255,255,255,.08);border:1px solid rgba(85,167,255,.18);overflow:hidden;position:relative;max-width:360px}
    .kw-install-progress span{display:block;height:100%;border-radius:999px;background:linear-gradient(90deg,#5eaeff,#62b77e);min-width:0}
  `;
  if (!document.getElementById(miV4Style.id)) document.head.appendChild(miV4Style);

  removeTopServerButtons();
})();


(function(){
  Object.assign(T.es, {
    instanceTemplate: 'Plantilla',
    instanceTemplateDefault: 'Personalizada',
    instanceTemplatePve: 'PvE',
    instanceTemplatePvp: 'PvP',
    instanceTemplateTest: 'Test',
    instanceTemplateEvent: 'Evento',
    instanceTemplateVanilla: 'Vanilla',
    instanceTemplateModded: 'Modded',
    instanceSummaryTitle: 'Resumen de instancias',
    instanceSummaryTotal: 'Instancias',
    instanceSummaryRunning: 'Encendidas',
    instanceSummaryDownloading: 'Descargando',
    instanceSummaryErrors: 'Con error',
    instanceSummaryReady: 'Listas',
    instanceUpdateFiles: 'Actualizar archivos',
    instanceOpenServerFolder: 'Abrir servidor',
    instanceOpenBackups: 'Abrir backups',
    instanceOpenConfig: 'Abrir config',
    instanceOpenLogs: 'Abrir logs',
    instanceWarnings: 'Avisos',
    instanceWarningsNone: 'Sin avisos.',
    instanceActionError: 'No se pudo completar la acción de instancia.',
    instanceFilesUpdateStarted: 'Actualización del servidor lanzada.',
    instanceFolderOpened: 'Abriendo carpeta de la instancia.',
    instanceInstallSpeed: 'Velocidad',
    instanceInstallTransferred: 'Transferido',
    instanceInstallTransferredNone: 'Sin datos todavía',
    instanceRootOpen: 'Abrir raíz',
    instanceTemplateHint: 'Puedes crear la instancia ya con un perfil base y luego afinarla.',
    instanceDashboardHint: 'Vista rápida de todas las instancias del kit.',
    instanceSelectToEdit: 'Los ajustes, backups, tareas y watchdog trabajan sobre la instancia activa.',
  });
  Object.assign(T.en, {
    instanceTemplate: 'Template',
    instanceTemplateDefault: 'Custom',
    instanceTemplatePve: 'PvE',
    instanceTemplatePvp: 'PvP',
    instanceTemplateTest: 'Test',
    instanceTemplateEvent: 'Event',
    instanceTemplateVanilla: 'Vanilla',
    instanceTemplateModded: 'Modded',
    instanceSummaryTitle: 'Instances summary',
    instanceSummaryTotal: 'Instances',
    instanceSummaryRunning: 'Running',
    instanceSummaryDownloading: 'Downloading',
    instanceSummaryErrors: 'With error',
    instanceSummaryReady: 'Ready',
    instanceUpdateFiles: 'Update files',
    instanceOpenServerFolder: 'Open server',
    instanceOpenBackups: 'Open backups',
    instanceOpenConfig: 'Open config',
    instanceOpenLogs: 'Open logs',
    instanceWarnings: 'Warnings',
    instanceWarningsNone: 'No warnings.',
    instanceActionError: 'The instance action could not be completed.',
    instanceFilesUpdateStarted: 'Server update launched.',
    instanceFolderOpened: 'Opening instance folder.',
    instanceInstallSpeed: 'Speed',
    instanceInstallTransferred: 'Transferred',
    instanceInstallTransferredNone: 'No transfer data yet',
    instanceRootOpen: 'Open root',
    instanceTemplateHint: 'Create the instance with a base profile and fine-tune it later.',
    instanceDashboardHint: 'Quick view of every kit instance.',
    instanceSelectToEdit: 'Settings, backups, tasks and watchdog work on the active instance.',
  });

  const esc3 = v => (typeof escapeHtml === 'function' ? escapeHtml(v ?? '') : String(v ?? ''));

  function kwTemplateOptions(selected=''){
    const value = String(selected || '').toLowerCase();
    const rows = [
      ['', t('instanceTemplateDefault')],
      ['pve', t('instanceTemplatePve')],
      ['pvp', t('instanceTemplatePvp')],
      ['test', t('instanceTemplateTest')],
      ['event', t('instanceTemplateEvent')],
      ['vanilla', t('instanceTemplateVanilla')],
      ['modded', t('instanceTemplateModded')],
    ];
    return rows.map(([v,l]) => `<option value="${esc3(v)}" ${String(v)===value?'selected':''}>${esc3(l)}</option>`).join('');
  }

  function kwInstancesSummaryHtml(){
    const sum = (state.state && state.state.instances_summary) || {};
    const cards = [
      [t('instanceSummaryTotal'), sum.total ?? 0],
      [t('instanceSummaryRunning'), sum.running ?? 0],
      [t('instanceSummaryDownloading'), sum.downloading ?? 0],
      [t('instanceSummaryReady'), sum.ready ?? 0],
      [t('instanceSummaryErrors'), sum.errors ?? 0],
    ];
    return `<div class="card panel"><div class="panel-head-inline"><h2>${t('instanceSummaryTitle')}</h2><span class="kw-instance-muted">${t('instanceDashboardHint')}</span></div><div class="kw-mini-stats">${cards.map(([label,val])=>`<div class="stat card kw-mini-stat"><small>${esc3(label)}</small><strong>${esc3(val)}</strong></div>`).join('')}</div></div>`;
  }

  async function kwOpenInstanceArea(id, area){
    try {
      const res = await api('/api/instances/open-folder', 'POST', { id, area });
      toast((res && res.message) || t('instanceFolderOpened'));
    } catch(err){ toast((err && err.message) || t('instanceActionError'), true); }
  }
  window.kwOpenInstanceArea = kwOpenInstanceArea;

  async function kwUpdateInstanceFiles(id){
    try {
      const res = await api('/api/instances/update-files', 'POST', { id });
      toast((res && res.message) || t('instanceFilesUpdateStarted'));
      setTimeout(()=>refreshState(true).catch(()=>{}), 350);
    } catch(err){ toast((err && err.message) || t('instanceActionError'), true); }
  }
  window.kwUpdateInstanceFiles = kwUpdateInstanceFiles;

  const _kwCreateInstancePrev = window.kwCreateInstance;
  window.kwCreateInstance = async function(){
    const nameEl = document.getElementById('kwNewInstanceName');
    const tplEl = document.getElementById('kwInstanceTemplate');
    const name = String(nameEl && nameEl.value || '').trim();
    if(!name){ toast(t('createInstancePrompt'), true); if(nameEl) nameEl.focus(); return; }
    const downloadEl = document.getElementById('kwDownloadServerFiles');
    const download_server = downloadEl ? String(downloadEl.value || '1') !== '0' : true;
    const template = tplEl ? String(tplEl.value || '').trim() : '';
    const btn = document.getElementById('kwCreateInstanceBtn');
    const oldText = btn ? btn.textContent : '';
    try {
      if(btn){ btn.disabled = true; btn.textContent = t('instanceCreateWorking'); }
      const res = await api('/api/instances/create','POST',{name, download_server, template});
      if(nameEl) nameEl.value = '';
      toast((res && res.message) || t('instanceBackgroundDownloadStarted'));
      await refreshState(true);
      go('instances');
    } catch(err){ toast((err && err.message) || t('instanceCreateFailed'), true); }
    finally { if(btn){ btn.disabled = false; btn.textContent = oldText || t('instanceCreateNow'); } }
  };

  const _dashboardPrev = views.dashboard;
  views.dashboard = function(){
    return `${kwInstancesSummaryHtml()}<div class="kw-instance-muted" style="margin:10px 4px 0">${t('instanceSelectToEdit')}</div>${_dashboardPrev()}`;
  };

  views.instances = function(){
    const rows = Array.isArray((state.state && state.state.instances_catalog)) ? state.state.instances_catalog : [];
    const active = String((state.state && state.state.active_instance_id) || '');
    const rootFolder = esc3(state?.state?.instances_root_folder || '');
    return `
      <div class="kw-instances-grid">
        ${kwInstancesSummaryHtml()}
        <div class="card panel">
          <h2>${t('instancesTitle')}</h2>
          <p class="kw-instance-muted">${t('instancesSubtitle')}</p>
          <div class="input-grid" style="margin-top:14px">
            <div class="field">
              <label>${t('instanceRootFolder')}</label>
              <div class="input-with-btn">
                <input id="kwInstancesRootFolder" value="${rootFolder}" placeholder="C:\\KarmaWorld\\Instancias">
                <button class="btn" type="button" onclick="kwBrowseInstancesRoot()">${t('instanceRootBrowse')}</button>
              </div>
              <div class="kw-instance-muted">${t('instanceRootHint')}</div>
            </div>
            <div class="field">
              <label>&nbsp;</label>
              <div class="inline-actions">
                <button class="btn btn-primary" onclick="kwSaveInstancesRoot()">${t('saveSettings')}</button>
                <button class="btn" onclick="kwRefreshInstances()">${t('instanceRefreshList')}</button>
                <button class="btn" onclick="kwOpenInstanceArea('${esc3(active || '')}','root')" ${active?'':'disabled'}>${t('instanceRootOpen')}</button>
              </div>
            </div>
          </div>
        </div>
        <div class="card panel">
          <h2>${t('createInstance')}</h2>
          <p class="kw-instance-muted">${t('instanceCreateHelp')}</p>
          <div class="input-grid" style="margin-top:14px">
            <div class="field">
              <label>${t('instanceName')}</label>
              <input id="kwNewInstanceName" value="" placeholder="${t('instanceNamePlaceholder')}">
            </div>
            <div class="field">
              <label>${t('instanceDownloadEnabled')}</label>
              <select id="kwDownloadServerFiles"><option value="1">${t('yes')}</option><option value="0">${t('no')}</option></select>
            </div>
            <div class="field">
              <label>${t('instanceTemplate')}</label>
              <select id="kwInstanceTemplate">${kwTemplateOptions('')}</select>
              <div class="kw-instance-muted">${t('instanceTemplateHint')}</div>
            </div>
            <div class="field">
              <label>&nbsp;</label>
              <div class="inline-actions">
                <button id="kwCreateInstanceBtn" class="btn btn-primary" onclick="kwCreateInstance()">${t('instanceCreateNow')}</button>
                <button class="btn" onclick="kwDuplicateInstance()" ${active?'':'disabled'}>${t('duplicateActive')}</button>
              </div>
            </div>
          </div>
        </div>
        <div class="kw-instance-cards">
          ${rows.length ? rows.map(row => {
            const pct = kwInstallPct(row);
            const target = esc3(row.install_target || row.server_folder || '-');
            const transferred = (Number(row.install_downloaded_mb||0) > 0 && Number(row.install_total_mb||0) > 0) ? `${Number(row.install_downloaded_mb).toFixed(2)} MB / ${Number(row.install_total_mb).toFixed(2)} MB` : t('instanceInstallTransferredNone');
            const speed = esc3(row.install_speed || '-');
            const warnings = Array.isArray(row.warnings) ? row.warnings : [];
            return `
            <article class="kw-instance-card ${String(row.id)===String(active) ? 'is-active' : ''}">
              <h3>
                <span>${esc3(row.name || row.id)}</span>
                <span class="kw-instance-badge ${row.running ? 'ok' : 'off'}">${row.running ? t('instanceRunning') : t('instanceStopped')}</span>
              </h3>
              <div class="kw-instance-meta">
                <div>${t('activeInstance')}</div><div>${row.active ? '✔' : '-'}</div>
                <div>${t('instanceInstallStatus')}</div><div><span class="kw-instance-badge ${kwInstallBadgeClass(row.install_status)}">${kwInstallStatusLabel(row.install_status)}</span> ${esc3(row.install_message || '')}</div>
                <div>${t('instanceInstallProgress')}</div><div><div class="kw-install-progress"><span style="width:${pct}%"></span></div><div class="kw-instance-muted" style="margin-top:6px">${pct > 0 ? pct + '%' : t('instanceInstallProgressNone')}</div></div>
                <div>${t('instanceInstallTransferred')}</div><div>${esc3(transferred)}</div>
                <div>${t('instanceInstallSpeed')}</div><div>${speed}</div>
                <div>${t('instanceInstallTarget')}</div><div>${target}</div>
                <div>${t('instanceServerName')}</div><div>${esc3(row.server_name || '-')}</div>
                <div>${t('instanceFolder')}</div><div>${esc3(row.server_folder || '-')}</div>
                <div>${t('instanceExecutable')}</div><div>${esc3(row.executable_path || '-')}</div>
                <div>${t('instanceTheme')}</div><div>${esc3(row.ui_theme || '-')}</div>
                <div>${t('instanceWarnings')}</div><div>${warnings.length ? warnings.map(w=>`<div>• ${esc3(w)}</div>`).join('') : esc3(t('instanceWarningsNone'))}</div>
              </div>
              <div class="kw-instance-actions">
                <button class="btn btn-primary" onclick="kwSelectInstance('${esc3(row.id)}')">${row.active ? t('selected') : t('select')}</button>
                <button class="btn" onclick="kwRenameInstance('${esc3(row.id)}')">${t('rename')}</button>
                <button class="btn" onclick="kwInstanceServerAction('${esc3(row.id)}','start')">${t('instanceStart')}</button>
                <button class="btn" onclick="kwInstanceServerAction('${esc3(row.id)}','restart')">${t('instanceRestart')}</button>
                <button class="btn btn-danger" onclick="kwInstanceServerAction('${esc3(row.id)}','stop')">${t('instanceStop')}</button>
                <button class="btn" onclick="kwUpdateInstanceFiles('${esc3(row.id)}')">${t('instanceUpdateFiles')}</button>
                <button class="btn" onclick="kwOpenInstanceArea('${esc3(row.id)}','server')">${t('instanceOpenServerFolder')}</button>
                <button class="btn" onclick="kwOpenInstanceArea('${esc3(row.id)}','backups')">${t('instanceOpenBackups')}</button>
                <button class="btn" onclick="kwOpenInstanceArea('${esc3(row.id)}','config')">${t('instanceOpenConfig')}</button>
                <button class="btn" onclick="kwOpenInstanceArea('${esc3(row.id)}','logs')">${t('instanceOpenLogs')}</button>
                <button class="btn btn-danger" onclick="kwDeleteInstance('${esc3(row.id)}')">${t('delete')}</button>
              </div>
            </article>`;
          }).join('') : `<div class="card panel"><h3>${t('noInstancesYet')}</h3><p class="kw-instance-muted">${t('instanceCreateFirstHint')}</p></div>`}
        </div>
      </div>`;
  };
})();

(function(){
  const escFix = v => (typeof escapeHtml === 'function' ? escapeHtml(v ?? '') : String(v ?? ''));
  if (typeof window.kwDuplicateActiveInstance === 'function') {
    window.kwDuplicateInstance = window.kwDuplicateActiveInstance;
  }

  Object.assign(T.es, {
    duplicateActive: 'Duplicar activa'
  });
  Object.assign(T.en, {
    duplicateActive: 'Duplicate active'
  });

  window.kwCreateInstance = async function(){
    const btn = document.getElementById('kwCreateInstanceBtn');
    const input = document.getElementById('kwNewInstanceName');
    const downloadEl = document.getElementById('kwDownloadServerFiles');
    const oldText = btn ? btn.textContent : '';
    try {
      if (state.section !== 'instances') {
        go('instances');
        setTimeout(() => { const el = document.getElementById('kwNewInstanceName'); if (el) el.focus(); }, 100);
        return;
      }
      const name = input ? String(input.value || '').trim() : '';
      if (!name) {
        toast(t('createInstancePrompt'), true);
        if (input) input.focus();
        return;
      }
      const download_server = downloadEl ? String(downloadEl.value || '1') !== '0' : true;
      if (btn) { btn.disabled = true; btn.textContent = t('instanceCreateWorking') || 'Creando...'; }
      const res = await api('/api/instances/create', 'POST', { name, download_server });
      if (input) input.value = '';
      await refreshState(true);
      go('instances');
      render(true);
      toast((res && res.message) || t('instanceCreateSuccess'));
    } catch (err) {
      toast((err && err.message) || t('instanceCreateFailed'), true);
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = oldText || t('instanceCreateNow'); }
    }
  };

  views.instances = function(){
    const rows = Array.isArray((state.state && state.state.instances_catalog)) ? state.state.instances_catalog : [];
    const active = String((state.state && state.state.active_instance_id) || '');
    const rootFolder = escFix(state?.state?.instances_root_folder || '');
    return `
      <div class="kw-instances-grid">
        ${typeof kwInstancesSummaryHtml === 'function' ? kwInstancesSummaryHtml() : ''}
        <div class="card panel">
          <h2>${t('instancesTitle')}</h2>
          <p class="kw-instance-muted">${t('instancesSubtitle')}</p>
          <div class="input-grid" style="margin-top:14px">
            <div class="field">
              <label>${t('instanceRootFolder')}</label>
              <div class="input-with-btn">
                <input id="kwInstancesRootFolder" value="${rootFolder}" placeholder="C:\\KarmaWorld\\Instancias">
                <button class="btn" type="button" onclick="kwBrowseInstancesRoot()">${t('instanceRootBrowse')}</button>
              </div>
              <div class="kw-instance-muted">${t('instanceRootHint')}</div>
            </div>
            <div class="field">
              <label>&nbsp;</label>
              <div class="inline-actions">
                <button class="btn btn-primary" onclick="kwSaveInstancesRoot()">${t('saveSettings')}</button>
                <button class="btn" onclick="kwRefreshInstances()">${t('instanceRefreshList')}</button>
                <button class="btn" onclick="kwOpenInstanceArea('${escFix(active || '')}','root')" ${active?'':'disabled'}>${t('instanceRootOpen')}</button>
              </div>
            </div>
          </div>
        </div>

        <div class="card panel">
          <h2>${t('createInstance')}</h2>
          <p class="kw-instance-muted">${t('instanceCreateHelp')}</p>
          <div class="input-grid" style="margin-top:14px">
            <div class="field">
              <label>${t('instanceName')}</label>
              <input id="kwNewInstanceName" value="" placeholder="${t('instanceNamePlaceholder')}">
            </div>
            <div class="field">
              <label>${t('instanceDownloadEnabled')}</label>
              <select id="kwDownloadServerFiles"><option value="1">${t('yes')}</option><option value="0">${t('no')}</option></select>
            </div>
          </div>
          <div class="inline-actions" style="margin-top:14px">
            <button id="kwCreateInstanceBtn" class="btn btn-primary" onclick="kwCreateInstance()">${t('instanceCreateNow')}</button>
            <button class="btn" onclick="kwDuplicateInstance()" ${active?'':'disabled'}>${t('duplicateInstance')}</button>
          </div>
        </div>

        <div class="kw-instance-cards">
          ${rows.length ? rows.map(row => {
            const pct = typeof kwInstallPct === 'function' ? kwInstallPct(row) : 0;
            const target = escFix(row.install_target || row.server_folder || '-');
            const transferred = (Number(row.install_downloaded_mb||0) > 0 && Number(row.install_total_mb||0) > 0) ? `${Number(row.install_downloaded_mb).toFixed(2)} MB / ${Number(row.install_total_mb).toFixed(2)} MB` : t('instanceInstallTransferredNone');
            const speed = escFix(row.install_speed || '-');
            const warnings = Array.isArray(row.warnings) ? row.warnings : [];
            return `
            <article class="kw-instance-card ${String(row.id)===String(active) ? 'is-active' : ''}">
              <h3>
                <span>${escFix(row.name || row.id)}</span>
                <span class="kw-instance-badge ${row.running ? 'ok' : 'off'}">${row.running ? t('instanceRunning') : t('instanceStopped')}</span>
              </h3>
              <div class="kw-instance-meta">
                <div>${t('activeInstance')}</div><div>${row.active ? '✔' : '-'}</div>
                <div>${t('instanceInstallStatus')}</div><div><span class="kw-instance-badge ${typeof kwInstallBadgeClass === 'function' ? kwInstallBadgeClass(row.install_status) : ''}">${typeof kwInstallStatusLabel === 'function' ? kwInstallStatusLabel(row.install_status) : escFix(row.install_status || '-')}</span> ${escFix(row.install_message || '')}</div>
                <div>${t('instanceInstallProgress')}</div><div><div class="kw-install-progress"><span style="width:${pct}%"></span></div><div class="kw-instance-muted" style="margin-top:6px">${pct > 0 ? pct + '%' : t('instanceInstallProgressNone')}</div></div>
                <div>${t('instanceInstallTransferred')}</div><div>${escFix(transferred)}</div>
                <div>${t('instanceInstallSpeed')}</div><div>${speed}</div>
                <div>${t('instanceInstallTarget')}</div><div>${target}</div>
                <div>${t('instanceServerName')}</div><div>${escFix(row.server_name || '-')}</div>
                <div>${t('instanceFolder')}</div><div>${escFix(row.server_folder || '-')}</div>
                <div>${t('instanceExecutable')}</div><div>${escFix(row.executable_path || '-')}</div>
                <div>${t('instanceTheme')}</div><div>${escFix(row.ui_theme || '-')}</div>
                <div>${t('instanceWarnings')}</div><div>${warnings.length ? warnings.map(w=>`<div>• ${escFix(w)}</div>`).join('') : escFix(t('instanceWarningsNone'))}</div>
              </div>
              <div class="kw-instance-actions">
                <button class="btn btn-primary" onclick="kwSelectInstance('${escFix(row.id)}')">${row.active ? t('selected') : t('select')}</button>
                <button class="btn" onclick="kwRenameInstance('${escFix(row.id)}')">${t('rename')}</button>
                <button class="btn" onclick="kwInstanceServerAction('${escFix(row.id)}','start')">${t('instanceStart')}</button>
                <button class="btn" onclick="kwInstanceServerAction('${escFix(row.id)}','restart')">${t('instanceRestart')}</button>
                <button class="btn btn-danger" onclick="kwInstanceServerAction('${escFix(row.id)}','stop')">${t('instanceStop')}</button>
                <button class="btn" onclick="kwUpdateInstanceFiles('${escFix(row.id)}')">${t('instanceUpdateFiles')}</button>
                <button class="btn" onclick="kwOpenInstanceArea('${escFix(row.id)}','server')">${t('instanceOpenServerFolder')}</button>
                <button class="btn" onclick="kwOpenInstanceArea('${escFix(row.id)}','backups')">${t('instanceOpenBackups')}</button>
                <button class="btn" onclick="kwOpenInstanceArea('${escFix(row.id)}','config')">${t('instanceOpenConfig')}</button>
                <button class="btn" onclick="kwOpenInstanceArea('${escFix(row.id)}','logs')">${t('instanceOpenLogs')}</button>
                <button class="btn btn-danger" onclick="kwDeleteInstance('${escFix(row.id)}')">${t('delete')}</button>
              </div>
            </article>`;
          }).join('') : `<div class="card panel"><h3>${t('noInstancesYet')}</h3><p class="kw-instance-muted">${t('instanceCreateFirstHint')}</p></div>`}
        </div>
      </div>`;
  };
})();


(function(){
  Object.assign(T.es, {
    instancesTitle: 'Instancias del servidor',
    instancesSubtitle: 'Crea perfiles separados con sus propias rutas, datos y configuración. Todo el panel trabaja sobre la instancia seleccionada.',
    createInstance: 'Nueva instancia',
    instanceName: 'Nombre de la instancia',
    instanceNamePlaceholder: 'Ejemplo: Servidor 1',
    instanceCreateHelp: 'Al crear una instancia se prepara su carpeta propia y, si quieres, se descargan los archivos del servidor dedicado con SteamCMD.',
    instanceCreateNow: 'Crear instancia ahora',
    duplicateInstance: 'Duplicar activa',
    instanceSelectOnlyHint: 'Selecciona una instancia para usar sus funciones y ajustes.',
    instanceSelect: 'Seleccionar',
    instanceSelected: 'Seleccionada',
    instanceOnlyActiveActions: 'Las acciones de servidor, descarga, carpetas y borrado solo funcionan sobre la instancia seleccionada.',
    instanceDeleteNeedSelect: 'Primero selecciona la instancia que quieres borrar.',
    instanceActionNeedSelect: 'Primero selecciona la instancia que quieres usar.',
    instanceRefreshList: 'Refrescar instancias',
    instanceRootBrowse: 'Elegir carpeta',
    instanceRootBrowseTitle: 'Selecciona la carpeta raíz para nuevas instancias',
    instanceInstallStatus: 'Descarga',
    instanceInstallProgress: 'Progreso',
    instanceInstallTarget: 'Descargando en',
    instanceInstallTransferred: 'Transferido',
    instanceInstallTransferredNone: 'Sin datos todavía',
    instanceInstallSpeed: 'Velocidad',
    instanceWarnings: 'Avisos',
    instanceWarningsNone: 'Sin avisos.',
    instanceRootOpen: 'Abrir raíz',
    instanceOpenServerFolder: 'Abrir servidor',
    instanceOpenBackups: 'Abrir backups',
    instanceOpenConfig: 'Abrir config',
    instanceOpenLogs: 'Abrir logs',
    instanceUpdateFiles: 'Actualizar archivos',
    instanceInstallIdle: 'Sin descarga',
    instanceInstallQueued: 'En cola',
    instanceInstallInstalling: 'Descargando',
    instanceInstallReady: 'Lista',
    instanceInstallError: 'Error',
    instanceInstallUnknown: 'Desconocido',
    instanceInstallProgressNone: 'Esperando progreso...',
    themeDark: 'Oscuro',
    themeOcean: 'Océano',
    themeEmerald: 'Esmeralda',
    themeViolet: 'Violeta',
    themeSunset: 'Atardecer',
    instanceNoTheme: 'Sin tema',
    instanceFolderOpened: 'Abriendo carpeta.',
    instanceFilesUpdateStarted: 'Actualización del servidor lanzada.',
    instanceActionError: 'No se pudo completar la acción de instancia.',
    instanceSaved: 'Instancias actualizadas.',
    instanceCreateSuccess: 'Instancia creada correctamente.',
    instanceCreateFailed: 'No se pudo crear la instancia.',
    instanceCreateWorking: 'Creando instancia...'
  });
  Object.assign(T.en, {
    instancesTitle: 'Server instances',
    instancesSubtitle: 'Create separate profiles with their own paths, data and configuration. The whole panel works with the selected instance.',
    createInstance: 'New instance',
    instanceName: 'Instance name',
    instanceNamePlaceholder: 'Example: Server 1',
    instanceCreateHelp: 'Creating an instance prepares its own folder and, if you want, downloads the dedicated server files with SteamCMD.',
    instanceCreateNow: 'Create instance now',
    duplicateInstance: 'Duplicate active',
    instanceSelectOnlyHint: 'Select an instance to use its functions and settings.',
    instanceSelect: 'Select',
    instanceSelected: 'Selected',
    instanceOnlyActiveActions: 'Server actions, download, folders and deletion only work on the selected instance.',
    instanceDeleteNeedSelect: 'Select the instance you want to delete first.',
    instanceActionNeedSelect: 'Select the instance you want to use first.',
    instanceRefreshList: 'Refresh instances',
    instanceRootBrowse: 'Choose folder',
    instanceRootBrowseTitle: 'Select the root folder for new instances',
    instanceInstallStatus: 'Download',
    instanceInstallProgress: 'Progress',
    instanceInstallTarget: 'Downloading to',
    instanceInstallTransferred: 'Transferred',
    instanceInstallTransferredNone: 'No data yet',
    instanceInstallSpeed: 'Speed',
    instanceWarnings: 'Warnings',
    instanceWarningsNone: 'No warnings.',
    instanceRootOpen: 'Open root',
    instanceOpenServerFolder: 'Open server',
    instanceOpenBackups: 'Open backups',
    instanceOpenConfig: 'Open config',
    instanceOpenLogs: 'Open logs',
    instanceUpdateFiles: 'Update files',
    instanceInstallIdle: 'No download',
    instanceInstallQueued: 'Queued',
    instanceInstallInstalling: 'Downloading',
    instanceInstallReady: 'Ready',
    instanceInstallError: 'Error',
    instanceInstallUnknown: 'Unknown',
    instanceInstallProgressNone: 'Waiting for progress...',
    themeDark: 'Dark',
    themeOcean: 'Ocean',
    themeEmerald: 'Emerald',
    themeViolet: 'Violet',
    themeSunset: 'Sunset',
    instanceNoTheme: 'No theme',
    instanceFolderOpened: 'Opening folder.',
    instanceFilesUpdateStarted: 'Server update started.',
    instanceActionError: 'The instance action could not be completed.',
    instanceSaved: 'Instances updated.',
    instanceCreateSuccess: 'Instance created successfully.',
    instanceCreateFailed: 'The instance could not be created.',
    instanceCreateWorking: 'Creating instance...'
  });

  function miEsc(v){ return String(v ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
  function miList(){ return Array.isArray(state?.state?.instances_catalog) ? state.state.instances_catalog : []; }
  function miActive(){ return String(state?.state?.active_instance_id || '').trim(); }
  function miRow(id){ return miList().find(r => String(r.id) === String(id)) || null; }
  function miIsActive(id){ return String(id || '') === miActive(); }
  function miThemeLabel(raw){ const key = String(raw || '').trim().toLowerCase(); const map = {dark:t('themeDark'), ocean:t('themeOcean'), emerald:t('themeEmerald'), violet:t('themeViolet'), sunset:t('themeSunset')}; return map[key] || (raw ? String(raw) : t('instanceNoTheme')); }
  function miInstallStatusLabel(status){ const map = {idle:t('instanceInstallIdle'), queued:t('instanceInstallQueued'), installing:t('instanceInstallInstalling'), ready:t('instanceInstallReady'), error:t('instanceInstallError')}; return map[String(status || '').trim().toLowerCase()] || t('instanceInstallUnknown'); }
  function miInstallBadgeClass(status){ const s = String(status || '').trim().toLowerCase(); if (s === 'ready') return 'ok'; if (s === 'error') return 'off'; return ''; }
  function miProgress(row){ const n = Number(row && row.install_progress); return Number.isFinite(n) ? Math.max(0, Math.min(100, Math.round(n))) : 0; }
  function miTransferred(row){ const d = Number(row && row.install_downloaded_mb); const tot = Number(row && row.install_total_mb); if (!Number.isFinite(d) || d <= 0) return t('instanceInstallTransferredNone'); if (Number.isFinite(tot) && tot > 0) return `${d.toFixed(1)} / ${tot.toFixed(1)} MB`; return `${d.toFixed(1)} MB`; }
  function miSpeed(row){ return String(row && row.install_speed || '').trim() || '-'; }
  function miTarget(row){ return String(row && (row.install_target || row.server_folder) || '').trim() || '-'; }
  function miWarnings(row){ const m = String(row && row.install_message || '').trim(); return m || t('instanceWarningsNone'); }
  async function miSafeRefresh(){ await refreshState(true); render(true); }

  window.kwBrowseInstancesRoot = async function(){ try { await browseField('kwInstancesRootFolder', 'folder', t('instanceRootBrowseTitle')); } catch(err){ toast((err && err.message) || t('error'), true); } };
  window.kwSaveInstancesRoot = async function(){ try { const el = document.getElementById('kwInstancesRootFolder'); const res = await api('/api/instances/root','POST',{folder: el ? el.value : ''}); await miSafeRefresh(); toast((res && res.message) || t('instanceSaved')); } catch(err){ toast((err && err.message) || t('instanceActionError'), true); } };
  window.kwCreateInstance = async function(){ const btn = document.getElementById('kwCreateInstanceBtn'); const oldText = btn ? btn.textContent : ''; try { const input = document.getElementById('kwNewInstanceName'); const downloadEl = document.getElementById('kwDownloadServerFiles'); const name = input ? String(input.value || '').trim() : ''; const download_server = downloadEl ? String(downloadEl.value || '1') !== '0' : true; if (btn){ btn.disabled = true; btn.textContent = t('instanceCreateWorking'); } const res = await api('/api/instances/create','POST',{name, download_server}); if (input) input.value = ''; await miSafeRefresh(); toast((res && res.message) || t('instanceCreateSuccess')); } catch(err){ toast((err && err.message) || t('instanceCreateFailed'), true); } finally { if (btn){ btn.disabled = false; btn.textContent = oldText || t('instanceCreateNow'); } } };
  window.kwDuplicateInstance = async function(){ try { const source_id = miActive(); if (!source_id){ toast(t('instanceActionNeedSelect'), true); return; } const name = window.prompt(t('duplicateInstancePrompt'), ''); if (name === null) return; const res = await api('/api/instances/duplicate','POST',{source_id, name}); await miSafeRefresh(); toast((res && res.message) || t('instanceSaved')); } catch(err){ toast((err && err.message) || t('instanceActionError'), true); } };
  window.kwSelectInstance = async function(id){ try { if (!id || miIsActive(id)) return; if (!window.confirm(t('switchInstanceConfirm'))) return; const res = await api('/api/instances/select','POST',{id}); await miSafeRefresh(); toast((res && res.message) || t('instanceSaved')); } catch(err){ toast((err && err.message) || t('instanceActionError'), true); } };
  window.kwRenameInstance = async function(id){ try { if (!miIsActive(id)){ toast(t('instanceActionNeedSelect'), true); return; } const row = miRow(id); const name = window.prompt(t('renameInstancePrompt'), row ? row.name : ''); if (name === null) return; const res = await api('/api/instances/update','POST',{id, name}); await miSafeRefresh(); toast((res && res.message) || t('instanceSaved')); } catch(err){ toast((err && err.message) || t('instanceActionError'), true); } };
  window.kwDeleteInstance = async function(id){ try { if (!miIsActive(id)){ toast(t('instanceDeleteNeedSelect'), true); return; } if (!window.confirm(t('deleteInstanceConfirm'))) return; const res = await api('/api/instances/delete','POST',{id}); await miSafeRefresh(); toast((res && res.message) || t('instanceSaved')); } catch(err){ toast((err && err.message) || t('instanceActionError'), true); } };
  window.kwInstanceServerAction = async function(id, action){ try { if (!miIsActive(id)){ toast(t('instanceActionNeedSelect'), true); return; } const res = await api('/api/instances/server-action','POST',{id, action}); await miSafeRefresh(); toast((res && res.message) || t('instanceSaved')); } catch(err){ toast((err && err.message) || t('instanceActionError'), true); } };
  window.kwOpenInstanceArea = async function(id, area){ try { if (!miIsActive(id)){ toast(t('instanceActionNeedSelect'), true); return; } const res = await api('/api/instances/open-folder','POST',{id, area}); toast((res && res.message) || t('instanceFolderOpened')); } catch(err){ toast((err && err.message) || t('instanceActionError'), true); } };
  window.kwUpdateInstanceFiles = async function(id){ try { if (!miIsActive(id)){ toast(t('instanceActionNeedSelect'), true); return; } const res = await api('/api/instances/update-files','POST',{id}); await miSafeRefresh(); toast((res && res.message) || t('instanceFilesUpdateStarted')); } catch(err){ toast((err && err.message) || t('instanceActionError'), true); } };
  window.kwRefreshInstances = async function(){ try { await miSafeRefresh(); toast(t('instanceRefreshList')); } catch(err){ toast((err && err.message) || t('instanceActionError'), true); } };

  views.instances = function(){ const list = miList(); const active = miActive(); const rootFolder = miEsc(state?.state?.instances_root_folder || ''); return `
      <div class="kw-instances-grid kw-final-grid">
        <div class="card panel">
          <h2>${t('instancesTitle')}</h2>
          <p class="kw-instance-muted">${t('instancesSubtitle')}</p>
          <div class="input-grid" style="margin-top:14px">
            <div class="field">
              <label>${t('instanceRootFolder')}</label>
              <div class="input-with-btn"><input id="kwInstancesRootFolder" value="${rootFolder}" placeholder="D:/KarmaWorld_Servers"><button class="btn" type="button" onclick="kwBrowseInstancesRoot()">${t('instanceRootBrowse')}</button></div>
              <div class="kw-instance-muted">${t('instanceRootHint')}</div>
            </div>
            <div class="field">
              <label>&nbsp;</label>
              <div class="inline-actions"><button class="btn btn-primary" onclick="kwSaveInstancesRoot()">${t('saveInstanceRoot')}</button><button class="btn" onclick="kwRefreshInstances()">${t('instanceRefreshList')}</button><button class="btn" onclick="kwOpenInstanceArea('${miEsc(active)}','root')" ${active ? '' : 'disabled'}>${t('instanceRootOpen')}</button></div>
            </div>
          </div>
        </div>
        <div class="card panel">
          <h2>${t('createInstance')}</h2>
          <p class="kw-instance-muted">${t('instanceCreateHelp')}</p>
          <div class="input-grid" style="margin-top:14px">
            <div class="field"><label>${t('instanceName')}</label><input id="kwNewInstanceName" value="" placeholder="${t('instanceNamePlaceholder')}"></div>
            <div class="field"><label>${t('instanceDownloadEnabled')}</label><select id="kwDownloadServerFiles"><option value="1" selected>${t('yes')}</option><option value="0">${t('no')}</option></select></div>
          </div>
          <div class="inline-actions" style="margin-top:14px"><button id="kwCreateInstanceBtn" class="btn btn-primary" onclick="kwCreateInstance()">${t('instanceCreateNow')}</button><button class="btn" onclick="kwDuplicateInstance()" ${active ? '' : 'disabled'}>${t('duplicateInstance')}</button></div>
          <div class="kw-instance-muted" style="margin-top:12px">${t('instanceOnlyActiveActions')}</div>
        </div>
        <div class="kw-instance-cards">
          ${list.length ? list.map(row => { const isActive = String(row.id) === String(active); const pct = miProgress(row); const progressText = pct > 0 ? `${pct}%` : t('instanceInstallProgressNone'); return `
            <article class="kw-instance-card ${isActive ? 'is-active' : ''}">
              <h3><span>${miEsc(row.name)}</span><span class="kw-instance-badge ${row.running ? 'ok' : 'off'}">${row.running ? t('instanceRunning') : t('instanceStopped')}</span></h3>
              <div class="kw-instance-meta">
                <div>${t('activeInstance')}</div><div>${isActive ? t('instanceSelected') : t('instanceSelectOnlyHint')}</div>
                <div>${t('instanceInstallStatus')}</div><div><span class="kw-instance-badge ${miInstallBadgeClass(row.install_status)}">${miInstallStatusLabel(row.install_status)}</span></div>
                <div>${t('instanceInstallProgress')}</div><div><div class="kw-install-progress"><span style="width:${pct}%"></span></div><div class="kw-instance-muted" style="margin-top:6px">${progressText}</div></div>
                <div>${t('instanceInstallTransferred')}</div><div>${miEsc(miTransferred(row))}</div>
                <div>${t('instanceInstallSpeed')}</div><div>${miEsc(miSpeed(row))}</div>
                <div>${t('instanceInstallTarget')}</div><div>${miEsc(miTarget(row))}</div>
                <div>${t('instanceServerName')}</div><div>${miEsc(row.server_name || '-')}</div>
                <div>${t('instanceFolder')}</div><div>${miEsc(row.server_folder || '-')}</div>
                <div>${t('instanceExecutable')}</div><div>${miEsc(row.executable_path || '-')}</div>
                <div>${t('instanceTheme')}</div><div>${miEsc(miThemeLabel(row.ui_theme))}</div>
                <div>${t('pid')}</div><div>${row.running ? miEsc(row.pid || '-') : '-'}</div>
                <div>${t('instanceWarnings')}</div><div>${miEsc(miWarnings(row))}</div>
              </div>
              <div class="kw-instance-actions">
                ${isActive ? `<button class="btn btn-primary" disabled>${t('instanceSelected')}</button><button class="btn" onclick="kwRenameInstance('${miEsc(row.id)}')">${t('renameInstance')}</button><button class="btn" onclick="kwInstanceServerAction('${miEsc(row.id)}','start')">${t('instanceStart')}</button><button class="btn" onclick="kwInstanceServerAction('${miEsc(row.id)}','restart')">${t('instanceRestart')}</button><button class="btn btn-danger" onclick="kwInstanceServerAction('${miEsc(row.id)}','stop')">${t('instanceStop')}</button><button class="btn" onclick="kwUpdateInstanceFiles('${miEsc(row.id)}')">${t('instanceUpdateFiles')}</button><button class="btn" onclick="kwOpenInstanceArea('${miEsc(row.id)}','server')">${t('instanceOpenServerFolder')}</button><button class="btn" onclick="kwOpenInstanceArea('${miEsc(row.id)}','backups')">${t('instanceOpenBackups')}</button><button class="btn" onclick="kwOpenInstanceArea('${miEsc(row.id)}','config')">${t('instanceOpenConfig')}</button><button class="btn" onclick="kwOpenInstanceArea('${miEsc(row.id)}','logs')">${t('instanceOpenLogs')}</button><button class="btn btn-danger" onclick="kwDeleteInstance('${miEsc(row.id)}')">${t('deleteInstance')}</button>` : `<button class="btn btn-primary" onclick="kwSelectInstance('${miEsc(row.id)}')">${t('instanceSelect')}</button>`}
              </div>
            </article>`; }).join('') : `<div class="card panel"><h3>${t('noInstancesYet')}</h3><p class="kw-instance-muted">${t('instanceCreateFirstHint')}</p></div>`}
        </div>
      </div>`; };

  const style = document.createElement('style');
  style.id = 'kw-v81-final-fixes';
  style.textContent = `
    .hero h1{font-size:clamp(34px,5vw,72px)!important;line-height:1.02;word-break:break-word;overflow-wrap:anywhere}
    .panel h2{font-size:clamp(22px,2vw,38px);line-height:1.1;word-break:break-word}
    .panel h3{font-size:clamp(18px,1.5vw,28px);line-height:1.15;word-break:break-word}
    .stats{grid-template-columns:repeat(auto-fit,minmax(220px,1fr))!important}
    .stat,.kw-instance-card,.card.panel{min-width:0}
    .stat strong{font-size:clamp(22px,2.2vw,46px)!important;line-height:1.05;display:block;word-break:break-word;overflow-wrap:anywhere}
    .stat small,.label-grid div,.kw-instance-meta div,.kw-instance-muted,.hero p{overflow-wrap:anywhere;word-break:break-word}
    .kw-instance-cards{display:grid!important;grid-template-columns:repeat(auto-fit,minmax(min(360px,100%),1fr))!important;gap:16px}
    .kw-instance-card{display:flex;flex-direction:column;gap:12px;padding:18px 18px 20px}
    .kw-instance-meta{display:grid;grid-template-columns:minmax(120px,160px) minmax(0,1fr)!important;gap:8px 14px}
    .kw-instance-actions{display:flex;flex-wrap:wrap;gap:10px}
    .kw-instance-actions .btn{white-space:normal;line-height:1.15}
    .kw-install-progress{height:14px;border-radius:999px;background:rgba(255,255,255,.08);border:1px solid rgba(85,167,255,.18);overflow:hidden;position:relative;max-width:420px;width:100%}
    .kw-install-progress span{display:block;height:100%;border-radius:999px;background:linear-gradient(90deg,#5eaeff,#62b77e)}
    .kw-instance-card.is-active{border-color:rgba(110,160,222,.32);box-shadow:inset 0 0 0 1px rgba(87,151,255,.14)}
    .kw-instance-badge{display:inline-flex;align-items:center;gap:8px;padding:7px 10px;border-radius:999px;border:1px solid rgba(255,255,255,.08);font-size:12px;font-weight:700;max-width:100%;white-space:normal}
    .kw-instance-badge.ok{background:rgba(98,183,126,.14);color:#bff4cf}.kw-instance-badge.off{background:rgba(240,103,103,.12);color:#ffd0d0}
    .main-area{overflow-y:auto!important;overflow-x:hidden!important;padding-bottom:44px}
    @media (max-width: 1100px){ .stats{grid-template-columns:repeat(auto-fit,minmax(190px,1fr))!important} }
    @media (max-width: 900px){ .app-shell{grid-template-columns:1fr!important}.sidebar{max-height:42vh}.main-area{height:auto!important}.hero{padding:22px}.hero-actions{justify-content:flex-start}.kw-instance-cards{grid-template-columns:1fr!important} }
  `;
  if (!document.getElementById(style.id)) document.head.appendChild(style);
})();


(()=>{
  Object.assign(T.es, {
    instanceCreateWorking: 'Creando instancia...',
    instanceCreateHelp: 'La descarga es manual. Crea la instancia y luego usa los botones de su tarjeta.',
    instanceStartDownload: 'Descargar',
    instanceStopDownload: 'Parar descarga',
    instanceRetryDownload: 'Reintentar',
    instanceCreateNow: 'Crear instancia ahora',
    instanceOpenRoot: 'Abrir raíz',
    instanceDeleteConfirmForce: '¿Borrar esta instancia? Se intentará parar el servidor y la descarga antes de eliminarla.',
    instanceFolderOpened: 'Abriendo carpeta.',
    instanceActionError: 'La acción de instancia no se pudo completar.',
    instanceRootHint: 'Opcional. Si la rellenas, las nuevas instancias crearán sus carpetas dentro de esa ruta elegida por ti.',
    instanceInstallTransferredNone: 'Sin datos todavía',
    instanceInstallProgressNone: 'Esperando progreso...',
    instanceWarningsNone: 'Sin avisos.',
    instanceNoTheme: 'Sin tema',
    instanceSelectOnlyHint: 'Pulsa Seleccionar para usar esta instancia',
    instanceSelected: 'Seleccionada'
  });
  Object.assign(T.en, {
    instanceCreateWorking: 'Creating instance...',
    instanceCreateHelp: 'Download is manual. Create the instance first, then use the buttons in its card.',
    instanceStartDownload: 'Download',
    instanceStopDownload: 'Stop download',
    instanceRetryDownload: 'Retry',
    instanceCreateNow: 'Create instance now',
    instanceOpenRoot: 'Open root',
    instanceDeleteConfirmForce: 'Delete this instance? The kit will try to stop the server and the download before removing it.',
    instanceFolderOpened: 'Opening folder.',
    instanceActionError: 'The instance action could not be completed.',
    instanceRootHint: 'Optional. If you set it, new instances will create their folders inside the path you choose.',
    instanceInstallTransferredNone: 'No data yet',
    instanceInstallProgressNone: 'Waiting for progress...',
    instanceWarningsNone: 'No warnings.',
    instanceNoTheme: 'No theme',
    instanceSelectOnlyHint: 'Press Select to use this instance',
    instanceSelected: 'Selected'
  });

  function v9Esc(v){ return String(v ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
  function v9List(){ return Array.isArray(state?.state?.instances_catalog) ? state.state.instances_catalog : []; }
  function v9Active(){ return String(state?.state?.active_instance_id || '').trim(); }
  function v9Row(id){ return v9List().find(r => String(r.id) === String(id)) || null; }
  function v9IsActive(id){ return String(id||'') === v9Active(); }
  function v9Theme(raw){ const key=String(raw||'').trim().toLowerCase(); const map={dark:t('themeDark'),ocean:t('themeOcean'),emerald:t('themeEmerald'),violet:t('themeViolet'),sunset:t('themeSunset')}; return map[key] || (raw ? String(raw) : t('instanceNoTheme')); }
  function v9StatusLabel(status){ const map={idle:t('instanceInstallIdle'),queued:t('instanceInstallQueued'),installing:t('instanceInstallInstalling'),ready:t('instanceInstallReady'),error:t('instanceInstallError')}; return map[String(status||'').trim().toLowerCase()] || t('instanceInstallUnknown'); }
  function v9StatusClass(status){ const s=String(status||'').trim().toLowerCase(); if(s==='ready') return 'ok'; if(s==='error') return 'off'; if(s==='installing' || s==='queued') return 'warn'; return ''; }
  function v9Pct(row){ const n=Number(row && row.install_progress); return Number.isFinite(n) ? Math.max(0, Math.min(100, Math.round(n))) : 0; }
  function v9Transferred(row){ const d=Number(row && row.install_downloaded_mb); const tot=Number(row && row.install_total_mb); if(!Number.isFinite(d) || d<=0) return t('instanceInstallTransferredNone'); if(Number.isFinite(tot) && tot>0) return `${d.toFixed(1)} / ${tot.toFixed(1)} MB`; return `${d.toFixed(1)} MB`; }
  function v9Speed(row){ return String(row && row.install_speed || '').trim() || '-'; }
  function v9Target(row){ return String(row && (row.install_target || row.server_folder) || '').trim() || '-'; }
  function v9Warn(row){ return String(row && row.install_message || '').trim() || t('instanceWarningsNone'); }
  function v9ApplyCss(){ const cssId='kw-v9-toast-pos'; if(document.getElementById(cssId)) return; const st=document.createElement('style'); st.id=cssId; st.textContent=`.sidebar{overflow-y:auto !important; overscroll-behavior:contain; max-height:100vh}.toast{position:fixed !important; top:50% !important; right:22px !important; left:auto !important; bottom:auto !important; transform:translateY(-50%) !important; z-index:999999 !important; max-width:min(420px,42vw)} .stats{grid-template-columns:repeat(auto-fit,minmax(190px,1fr)) !important} .stat strong{font-size:clamp(18px,1.8vw,34px) !important; line-height:1.08 !important; word-break:break-word} .kw-instance-progress-line{display:flex;align-items:center;gap:10px;flex-wrap:wrap} .kw-instance-progress-line .kw-install-progress{flex:1 1 280px;max-width:480px} .btn.btn-download{background:linear-gradient(180deg,#4fd37a,#2ea85b)!important;border-color:transparent!important;color:#fff!important} .kw-instance-actions{display:flex;flex-wrap:wrap;gap:10px} .kw-instance-card .kw-instance-meta{display:grid;grid-template-columns:minmax(130px,160px) minmax(0,1fr);gap:8px 16px} .kw-instance-meta div{min-width:0;overflow-wrap:anywhere;word-break:break-word}`; document.head.appendChild(st); }
  function v9EnableSidebarWheel(){ const sb=document.querySelector('.sidebar'); if(!sb || sb.__kwWheelBound) return; sb.__kwWheelBound=true; sb.addEventListener('wheel', e=>{ if(sb.scrollHeight > sb.clientHeight + 4){ e.preventDefault(); sb.scrollTop += e.deltaY; } }, {passive:false}); }
  v9ApplyCss(); setTimeout(v9EnableSidebarWheel,50); window.addEventListener('load', v9EnableSidebarWheel); setInterval(v9EnableSidebarWheel, 1500);
  async function v9Refresh(){ await refreshState(true); render(true); v9EnableSidebarWheel(); }

  window.kwBrowseInstancesRoot = async function(){ try{ await browseField('kwInstancesRootFolder','folder',t('instanceRootBrowseTitle')); } catch(err){ toast((err&&err.message)||t('error'), true); } };
  window.kwSaveInstancesRoot = async function(){ try{ const el=document.getElementById('kwInstancesRootFolder'); const folder=el ? String(el.value||'').trim() : ''; const res=await api('/api/instances/root','POST',{folder}); toast((res&&res.message)||t('instanceSaved')); await v9Refresh(); } catch(err){ toast((err&&err.message)||t('instanceActionError'), true); } };
  window.kwOpenRootFolder = async function(){ try{ const el=document.getElementById('kwInstancesRootFolder'); const folder=el ? String(el.value||'').trim() : ''; if(folder){ await api('/api/instances/root','POST',{folder}); } const res=await api('/api/instances/open-folder','POST',{area:'root'}); toast((res&&res.message)||t('instanceFolderOpened')); await v9Refresh(); } catch(err){ toast((err&&err.message)||t('instanceActionError'), true); } };
  window.kwCreateInstance = async function(){ const btn=document.getElementById('kwCreateInstanceBtn'); const oldText=btn?btn.textContent:''; try{ const input=document.getElementById('kwNewInstanceName'); const rootEl=document.getElementById('kwInstancesRootFolder'); const name=input ? String(input.value||'').trim() : ''; const root_folder=rootEl ? String(rootEl.value||'').trim() : ''; if(!name){ toast(t('createInstancePrompt'), true); if(input) input.focus(); return; } if(btn){ btn.disabled=true; btn.textContent=t('instanceCreateWorking'); } const res=await api('/api/instances/create','POST',{name, root_folder}); if(input) input.value=''; toast((res&&res.message)||t('instanceCreateSuccess')); await v9Refresh(); } catch(err){ toast((err&&err.message)||t('instanceCreateFailed'), true); } finally { if(btn){ btn.disabled=false; btn.textContent=oldText || t('instanceCreateNow'); } } };
  window.kwDuplicateInstance = async function(){ try{ const source_id=v9Active(); if(!source_id){ toast(t('instanceActionNeedSelect'), true); return; } const name=window.prompt(t('duplicateInstancePrompt'),''); if(name===null) return; const res=await api('/api/instances/duplicate','POST',{source_id,name}); toast((res&&res.message)||t('instanceSaved')); await v9Refresh(); } catch(err){ toast((err&&err.message)||t('instanceActionError'), true); } };
  window.kwSelectInstance = async function(id){ try{ if(!id || v9IsActive(id)) return; if(!window.confirm(t('switchInstanceConfirm'))) return; const res=await api('/api/instances/select','POST',{id}); toast((res&&res.message)||t('instanceSaved')); await v9Refresh(); } catch(err){ toast((err&&err.message)||t('instanceActionError'), true); } };
  window.kwRenameInstance = async function(id){ try{ if(!v9IsActive(id)){ toast(t('instanceActionNeedSelect'), true); return; } const row=v9Row(id); const name=window.prompt(t('renameInstancePrompt'), row ? row.name : ''); if(name===null) return; const res=await api('/api/instances/update','POST',{id,name}); toast((res&&res.message)||t('instanceSaved')); await v9Refresh(); } catch(err){ toast((err&&err.message)||t('instanceActionError'), true); } };
  window.kwDeleteInstance = async function(id){ try{ if(!v9IsActive(id)){ toast(t('instanceDeleteNeedSelect'), true); return; } if(!window.confirm(t('instanceDeleteConfirmForce'))) return; const res=await api('/api/instances/delete','POST',{id,force:true}); toast((res&&res.message)||t('instanceSaved')); await v9Refresh(); } catch(err){ toast((err&&err.message)||t('instanceActionError'), true); } };
  window.kwInstanceServerAction = async function(id, action){ try{ if(!v9IsActive(id)){ toast(t('instanceActionNeedSelect'), true); return; } if(action==='stop' && !window.confirm(t('stopConfirm'))) return; if(action==='restart' && !window.confirm(t('restartConfirm'))) return; const res=await api('/api/instances/server-action','POST',{id,action}); toast((res&&res.message)||t('instanceSaved')); await v9Refresh(); } catch(err){ toast((err&&err.message)||t('instanceActionError'), true); } };
  window.kwOpenInstanceArea = async function(id, area){ try{ if(area!=='root' && !v9IsActive(id)){ toast(t('instanceActionNeedSelect'), true); return; } const res=await api('/api/instances/open-folder','POST',{id,area}); toast((res&&res.message)||t('instanceFolderOpened')); } catch(err){ toast((err&&err.message)||t('instanceActionError'), true); } };
  window.kwDownloadAction = async function(id, action){ try{ if(!v9IsActive(id)){ toast(t('instanceActionNeedSelect'), true); return; } if(action==='stop' && !window.confirm(t('instanceStopDownload')+'?')) return; const res=await api('/api/instances/update-files','POST',{id,action}); toast((res&&res.message)||t('instanceSaved')); await v9Refresh(); } catch(err){ toast((err&&err.message)||t('instanceActionError'), true); } };
  window.kwRefreshInstances = async function(){ try{ await v9Refresh(); toast(t('instanceRefreshList')); } catch(err){ toast((err&&err.message)||t('instanceActionError'), true); } };

  views.instances = function(){ const list=v9List(); const active=v9Active(); const rootFolder=v9Esc(state?.state?.instances_root_folder || ''); return `
    <div class="kw-instances-grid">
      <div class="card panel">
        <h2>${t('instancesTitle')}</h2>
        <p class="kw-instance-muted">${t('instancesSubtitle')}</p>
        <div class="input-grid" style="margin-top:14px">
          <div class="field">
            <label>${t('instanceRootFolder')}</label>
            <div class="input-with-btn">
              <input id="kwInstancesRootFolder" value="${rootFolder}" placeholder="D:/KarmaWorld_Servers">
              <button class="btn" type="button" onclick="kwBrowseInstancesRoot()">${t('instanceRootBrowse')}</button>
            </div>
            <div class="kw-instance-muted">${t('instanceRootHint')}</div>
          </div>
          <div class="field">
            <label>&nbsp;</label>
            <div class="inline-actions"><button class="btn btn-primary" onclick="kwSaveInstancesRoot()">${t('saveInstanceRoot')}</button><button class="btn" onclick="kwRefreshInstances()">${t('instanceRefreshList')}</button><button class="btn" onclick="kwOpenRootFolder()">${t('instanceOpenRoot')}</button></div>
          </div>
        </div>
      </div>
      <div class="card panel">
        <h2>${t('createInstance')}</h2>
        <p class="kw-instance-muted">${t('instanceCreateHelp')}</p>
        <div class="input-grid" style="margin-top:14px"><div class="field"><label>${t('instanceName')}</label><input id="kwNewInstanceName" value="" placeholder="${t('instanceNamePlaceholder')}"></div></div>
        <div class="inline-actions" style="margin-top:14px"><button id="kwCreateInstanceBtn" class="btn btn-primary" onclick="kwCreateInstance()">${t('instanceCreateNow')}</button><button class="btn" onclick="kwDuplicateInstance()" ${active ? '' : 'disabled'}>${t('duplicateInstance')}</button></div>
        <div class="kw-instance-muted" style="margin-top:12px">${t('instanceOnlyActiveActions')}</div>
      </div>
      <div class="kw-instance-cards">
        ${list.length ? list.map(row => { const isActive=String(row.id)===String(active); const pct=v9Pct(row); const status=String(row.install_status||'idle').toLowerCase(); const showStart=status==='idle' || status==='error' || status==='ready'; const showStop=status==='installing' || status==='queued'; const showRetry=status==='error' || status==='ready' || status==='idle'; return `
          <article class="card panel kw-instance-card ${isActive ? 'is-active' : ''}">
            <h3 style="display:flex;justify-content:space-between;gap:12px;align-items:center"><span>${v9Esc(row.name)}</span><span class="kw-instance-badge ${row.running ? 'ok' : 'off'}">${row.running ? t('instanceRunning') : t('instanceStopped')}</span></h3>
            <div class="kw-instance-meta">
              <div>${t('activeInstance')}</div><div>${isActive ? t('instanceSelected') : t('instanceSelectOnlyHint')}</div>
              <div>${t('instanceInstallStatus')}</div><div><span class="kw-instance-badge ${v9StatusClass(row.install_status)}">${v9StatusLabel(row.install_status)}</span></div>
              <div>${t('instanceInstallProgress')}</div><div><div class="kw-instance-progress-line"><div class="kw-install-progress"><span style="width:${pct}%"></span></div>${showStart ? `<button class="btn btn-download" onclick="kwDownloadAction('${v9Esc(row.id)}','start')">${t('instanceStartDownload')}</button>` : ''}${showStop ? `<button class="btn btn-warning" onclick="kwDownloadAction('${v9Esc(row.id)}','stop')">${t('instanceStopDownload')}</button>` : ''}${showRetry ? `<button class="btn btn-download" onclick="kwDownloadAction('${v9Esc(row.id)}','retry')">${t('instanceRetryDownload')}</button>` : ''}</div><div class="kw-instance-muted" style="margin-top:6px">${pct>0 ? pct+'%' : t('instanceInstallProgressNone')}</div></div>
              <div>${t('instanceInstallTransferred')}</div><div>${v9Esc(v9Transferred(row))}</div>
              <div>${t('instanceInstallSpeed')}</div><div>${v9Esc(v9Speed(row))}</div>
              <div>${t('instanceInstallTarget')}</div><div>${v9Esc(v9Target(row))}</div>
              <div>${t('instanceServerName')}</div><div>${v9Esc(row.server_name || row.name || '-')}</div>
              <div>${t('instanceFolder')}</div><div>${v9Esc(row.server_folder || '-')}</div>
              <div>${t('instanceExecutable')}</div><div>${v9Esc(row.executable_path || '-')}</div>
              <div>${t('instanceTheme')}</div><div>${v9Esc(v9Theme(row.ui_theme))}</div>
              <div>${t('pid')}</div><div>${row.running ? v9Esc(row.pid || '-') : '-'}</div>
              <div>${t('instanceWarnings')}</div><div>${v9Esc(v9Warn(row))}</div>
            </div>
            <div class="kw-instance-actions">
              ${isActive ? `<button class="btn btn-primary" disabled>${t('instanceSelected')}</button><button class="btn" onclick="kwRenameInstance('${v9Esc(row.id)}')">${t('renameInstance')}</button><button class="btn" onclick="kwInstanceServerAction('${v9Esc(row.id)}','start')">${t('instanceStart')}</button><button class="btn" onclick="kwInstanceServerAction('${v9Esc(row.id)}','restart')">${t('instanceRestart')}</button><button class="btn btn-danger" onclick="kwInstanceServerAction('${v9Esc(row.id)}','stop')">${t('instanceStop')}</button><button class="btn" onclick="kwOpenInstanceArea('${v9Esc(row.id)}','server')">${t('instanceOpenServerFolder')}</button><button class="btn" onclick="kwOpenInstanceArea('${v9Esc(row.id)}','backups')">${t('instanceOpenBackups')}</button><button class="btn" onclick="kwOpenInstanceArea('${v9Esc(row.id)}','config')">${t('instanceOpenConfig')}</button><button class="btn" onclick="kwOpenInstanceArea('${v9Esc(row.id)}','logs')">${t('instanceOpenLogs')}</button><button class="btn btn-danger" onclick="kwDeleteInstance('${v9Esc(row.id)}')">${t('deleteInstance')}</button>` : `<button class="btn btn-primary" onclick="kwSelectInstance('${v9Esc(row.id)}')">${t('instanceSelect')}</button>`}
            </div>
          </article>`; }).join('') : `<div class="card panel"><h3>${t('noInstancesYet')}</h3><p class="kw-instance-muted">${t('instanceCreateFirstHint')}</p></div>`}
      </div>
    </div>`; };
})();


;(function(){
  const kwNeedInstanceSections = new Set(['watchdog','console','players','inventory','moderation','backups','tasks','serverconfig','settings']);
  function kwFinalActiveInstanceId(){ return String((window.state && window.state.state && window.state.state.active_instance_id) || '').trim(); }
  function kwFinalNeedSelectedMsg(){
    try { return typeof t === 'function' ? t('instanceSettingsOnlyText') : 'Selecciona una instancia primero.'; }
    catch(_) { return 'Selecciona una instancia primero.'; }
  }
  function kwFinalToast(msg, isErr){
    try { if (typeof toast === 'function') toast(msg, !!isErr); }
    catch(_) {}
  }
  const kwPrevGo = window.go || (typeof go === 'function' ? go : null);
  if (kwPrevGo) {
    const kwGuardedGo = function(section){
      const key = String(section || '').trim();
      if (kwNeedInstanceSections.has(key) && !kwFinalActiveInstanceId()) {
        kwFinalToast(kwFinalNeedSelectedMsg(), true);
        return kwPrevGo('instances');
      }
      return kwPrevGo(key);
    };
    window.go = kwGuardedGo;
    try { go = kwGuardedGo; } catch(_) {}
  }
  const kwPrevRender = window.render || (typeof render === 'function' ? render : null);
  if (kwPrevRender) {
    const kwGuardedRender = function(){
      try {
        if (window.state && kwNeedInstanceSections.has(String(window.state.section || '').trim()) && !kwFinalActiveInstanceId()) {
          window.state.section = 'instances';
        }
      } catch(_) {}
      return kwPrevRender.apply(this, arguments);
    };
    window.render = kwGuardedRender;
    try { render = kwGuardedRender; } catch(_) {}
  }
})();
