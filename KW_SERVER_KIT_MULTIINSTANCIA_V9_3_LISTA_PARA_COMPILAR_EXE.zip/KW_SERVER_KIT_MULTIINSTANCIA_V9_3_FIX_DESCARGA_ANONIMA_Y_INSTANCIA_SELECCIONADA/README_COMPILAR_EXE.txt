COMPILAR EXE EN WINDOWS

1. Descomprime esta carpeta en tu PC Windows.
2. Instala Python 3.11 o 3.12 de 64 bits y marca "Add Python to PATH".
3. Abre COMPILAR_UN_SOLO_EXE.bat con doble clic.
4. Espera a que termine.
5. El EXE saldrá en dist\KarmaWorld Server Kit.exe

Notas:
- Esta versión incluye patch-v37.js e instances.json en el spec para que el EXE no falle por faltar archivos.
- Si Windows bloquea la consola, ejecútalo como usuario normal, no hace falta administrador.
- Si pywebview falla al instalar, actualiza pip y vuelve a lanzar el BAT.
